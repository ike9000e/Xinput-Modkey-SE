#include "hxdw_detours_misc.h"
#include <windows.h>
#include <assert.h>
#include <functional>
#include "detours.h"

bool hxdw_GetPEFileImports( const char* szFname, std::vector<std::string>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	PDETOUR_BINARY pExeBin = 0;
	HANDLE hf2 = 0;
	hf2 = CreateFileA( szFname, GENERIC_READ, FILE_SHARE_READ,
					   0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
	if( !hf2 || hf2 == INVALID_HANDLE_VALUE ){
		err3 = "Failed to open input file.";
		return 0;
	}
	std::shared_ptr<int> ptr( 0, [&]( int* ){
			if(pExeBin){
				DetourBinaryClose( pExeBin ); pExeBin = 0;
			}
			if(hf2){
				CloseHandle( hf2 ); hf2 = 0;
			}
	} );
	pExeBin = DetourBinaryOpen( hf2 );
	if( !pExeBin ){
		err3 = "Binary open failed [M9qiZuVA]";
		return 0;
	}
	auto func2 = [&]( const char* szDllFname )->bool{
			outp.push_back( szDllFname );
			return 1;
	};
	std::function<bool(const char*)> func3(func2);
	DetourBinaryEditImports( pExeBin, &func3, 0,
			[]( PVOID user2, LPCSTR, LPCSTR szFile, LPCSTR* )->BOOL{
					auto func3 = *reinterpret_cast<std::function<bool(const char*)>*>(user2);
					return func3( szFile );
	}, 0, 0 );
	return 1;
}
bool hxdw_GetPEExports( const char* pathname, std::vector<std::string>& outp )
{
	HMODULE hDll = LoadLibraryExA( pathname, 0, DONT_RESOLVE_DLL_REFERENCES );
	if( !hDll )
		return 0;
	using Fnc2_t = std::function<bool(int, const char*)>;
    auto fnc2 = Fnc2_t( [&]( int nOrdinal, const char* szExportName )->bool{
			outp.push_back( szExportName );
			return 1;
	});
	DetourEnumerateExports( hDll, &fnc2,
			[]( PVOID user2, ULONG nOrdinal, LPCSTR pszSymbol, PVOID pbTarget )->BOOL{
					Fnc2_t* fnc2 = reinterpret_cast<Fnc2_t*>( user2 );
					assert(fnc2);
					return (*fnc2)( static_cast<int>(nOrdinal), pszSymbol );
	});
	FreeLibrary(hDll);
	return 1;
}
