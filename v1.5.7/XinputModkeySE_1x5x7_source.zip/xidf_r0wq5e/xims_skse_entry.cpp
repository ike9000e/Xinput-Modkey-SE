#include "xims_skse_entry.h"
//#include "xims_utils.h"
#include "xidf_functions.h"

extern XidfGlobals5* XidfGlobals6;

std::string xims_GetRuntimeAndBuildWarningText2( const SKSEInterface* skse3 )
{
	char bfr2[512], bfrGameRtVer[32], bfrSkseVer[32];
	sprintf_s( bfrGameRtVer, sizeof(bfrGameRtVer), "%d.%d.%d",
				GET_EXE_VERSION_MAJOR( skse3->runtimeVersion ),
				GET_EXE_VERSION_MINOR( skse3->runtimeVersion ),
				GET_EXE_VERSION_BUILD( skse3->runtimeVersion ) );
	sprintf_s( bfrSkseVer, sizeof(bfrSkseVer), "%d.%d.%d",
				GET_EXE_VERSION_MAJOR( skse3->skseVersion ),
				GET_EXE_VERSION_MINOR( skse3->skseVersion ),
				GET_EXE_VERSION_BUILD( skse3->skseVersion ) );

	assert( XidfGlobals6 );
	assert( !XidfGlobals6->srDllPath.empty() );
	const std::string srDllName2 = hxdw_SplitPath( XidfGlobals6->srDllPath.c_str() ).second;
	sprintf_s( bfr2, sizeof(bfr2),
				"WARNING: Unsupported runtime version.\n"
				"\n"
				"Mod Name: [%s]\n"
				"DLL Name: [%s]\n"
				"\n"
				"SKSE version expected: [%s], have: [%s]\n"
				"Game version expected: [%s], have: [%s]\n"
				"\n"
				"[s5760583]\n"
				"\n",
				XIDF_MOD_NAME,
				srDllName2.c_str(),
				CURRENT_RELEASE_SKSE_STR,
				bfrSkseVer,
				xims_GetBuildString2("XIMS_SkseGameRuntimeVersion2").c_str(),
				bfrGameRtVer );
	return bfr2;
}

#if SKSE_VERSION_INTEGER <= 2 && SKSE_VERSION_INTEGER_MINOR < 1  //{ [F3eU7D]

// Called by SKSE to learn about this plugin and check that it's
// safe to load it. This is SKSE64 old method, pre-AE.
extern "C"
bool
__declspec(dllexport)
SKSEPlugin_Query( const SKSEInterface* skse, PluginInfo* info )
{
	// populate info structure
	info->infoVersion =	PluginInfo::kInfoVersion;
	info->name        = XIDF_MOD_NAME;  //"Xinput Modkey SE (SKSE64)", old: "XinputModkeySeMcmByIkk"
	info->version     = 1;

	//static PluginHandle          g_pluginHandle = kPluginHandle_Invalid;
	//static SKSEPapyrusInterface* g_papyrus = 0;//NULL;

	// store plugin handle so we can identify ourselves later
	//g_pluginHandle = skse->GetPluginHandle();

	if( skse->isEditor ){
		assert(!"XIMS: ERROR: loaded in editor, this is unexpected." );
		return 0L;
	}else if( skse->runtimeVersion < CURRENT_RELEASE_RUNTIME ){
		//else if( skse->runtimeVersion != CURRENT_RELEASE_RUNTIME )
		//else if( skse->runtimeVersion != RUNTIME_VERSION_1_9_32_0 )
		//_MESSAGE("unsupported runtime version %08X", skse->runtimeVersion);
		std::string msg2 = xims_GetRuntimeAndBuildWarningText2( skse );
		msg2 += "Press Cancel to attempt exit process.\n";
		int rs2 = MessageBox( 0, msg2.c_str(), info->name, MB_ICONWARNING|MB_OKCANCEL );
		if( rs2 != IDOK ){
			ExitProcess(1);
			return 0L;
		}
	}
	// ### do not do anything else in this callback
	// ### only fill out PluginInfo and return true/false

	// supported runtime version
	return 1L; //ok.
}

#endif //} [F3eU7D]

#if SKSE_VERSION_INTEGER >= 2 && SKSE_VERSION_INTEGER_MINOR >= 1  //{ [oNGUsi]

// #include "skse64/PluginAPI.h"
extern "C" {
	// NOTE: This must be initialized using the agregate initialization.
	//       Otherwise the data wont be there, when the DLL is not yet fully loaded.
	//       Do not initialize using copy contructor too (class name infront of the agregate initialization braces), it wont make the data available as well.
	__declspec(dllexport)
	SKSEPluginVersionData SKSEPlugin_Version =
		{
			SKSEPluginVersionData::kVersion,
			0,   // 0: not providing any version info here.
			XIDF_MOD_NAME, //"'name' //Xinput Modkey SE (SKSE64)",
			"ike9000",   //'author'
			"https://www.nexusmods.com/skyrimspecialedition/mods/25052", //'supportEmail'
			//0,   // UInt32 versionIndependenceEx; // 0: not version independent (extended field)
			SKSEPluginVersionData::kVersionIndependentEx_NoStructUse,

			//0,   // UInt32 versionIndependence;  // 0: not version independent
			SKSEPluginVersionData::kVersionIndependent_Signatures,

			// UInt32 compatibleVersions[16]
			// RUNTIME_VERSION_1_5_97   //0x01050610 creation club
			// - one version before the first AE.
			// RUNTIME_VERSION_1_6_317 - anniversary edition version, 1st one.
			// RUNTIME_VERSION_1_6_640 - one version before the 1st gog version.
			// RUNTIME_VERSION_1_6_659_GOG - gog version, first release.
			//{ RUNTIME_VERSION_1_6_640, 0,},
			//{ RUNTIME_VERSION_1_5_97, RUNTIME_VERSION_1_6_640, RUNTIME_VERSION_1_6_659_GOG, 0,},
			// NOTE: 'compatibleVersions' probly doesnt matter.
			{ RUNTIME_VERSION_1_5_97, RUNTIME_VERSION_1_6_317, 0,},

			// UInt32 seVersionRequired;
			0,	// 0: works with any version of the script extender. you probably do not need to put anything here.
		};
}
#endif //} [oNGUsi]

// Called by SKSE to load this plugin.
extern "C"
bool
__declspec(dllexport)
SKSEPlugin_Load( const SKSEInterface* skse2 )
{
//	assert( !XidfGlobals6 );
//	if( !xidf_InitForProcess( 0 ) ){
//		return 0L;
//	}
	//MessageBox(0,"SKSEPlugin_Load() 02 [" __DATE__ __TIME__ "]", XIDF_MOD_NAME, 0 );
	assert( XidfGlobals6 );
	assert( XidfGlobals6->ini7 );
	if( skse2->runtimeVersion != CURRENT_RELEASE_RUNTIME ){
		bool bWarnOnStartupRtVerMiss2 = !!atoi( XidfGlobals6->ini7->getValue("s_main","bWarnOnStartupRtVerMiss2","1").c_str() );
		if( bWarnOnStartupRtVerMiss2 ){
			for(;;){
				std::string msg3;
				msg3 = xims_GetRuntimeAndBuildWarningText2( skse2 );
				msg3 += "Any in-game configuration and SkyUI integration will be disabled.\n";
				msg3 += "\n";
				msg3 += "Press [Retry] to continue starting the game.\n";
				msg3 += "Press [Ignore] to not show this message in the future.\n";
				int rs2 = MessageBox(0, msg3.c_str(), XIDF_MOD_NAME,
						MB_ICONWARNING | MB_ABORTRETRYIGNORE| MB_DEFBUTTON2 | 0);
				if( rs2 == IDIGNORE ){
					std::string sr2 = XidfGlobals6->ini7->getValue("s_main","szXinputDllName","");
					assert( !sr2.empty() );
					//
					XidfGlobals6->ini7->setValue("s_main","bWarnOnStartupRtVerMiss2","0");
					xidf_ReinitConfiguration3("w");
				}else if( rs2 == IDRETRY ){
					break;
				}else if( rs2 == IDABORT ){
					ExitProcess(1);
					break;
				}
			}
		}
	}else{
		SKSEPapyrusInterface* pPapyrus = 0;
		pPapyrus = reinterpret_cast<SKSEPapyrusInterface*>( skse2->QueryInterface( kInterface_Papyrus ) );
		if( !pPapyrus ){
			//MessageBox(0,"XIMS: ERROR: No Papyrus interface.", XIDF_MOD_NAME, 0 );
			assert(!"XIMS: ERROR: No Papyrus interface. This is unexpected [WH3Ihc]" );
		}
		bool bRegOk = pPapyrus->Register( xims_RegisterFuncs );
		if( !bRegOk ){
			//MessageBox(0,"XIMS: ERROR: Papyrus interface register call failed. This is unexpected [XoUf0N]", SKSEPlugin_Version.name, 0 );
			assert(!"XIMS: ERROR: register call failed. This is unexpected [XoUf0N]" );
		}//*/
	}
	return 1L;
}

BOOL WINAPI DllMain( HINSTANCE, DWORD dwReason, void* )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			//MessageBox(0,"DllMain 01 [" __DATE__ __TIME__ "]", XIDF_MOD_NAME, 0 );
			assert( !XidfGlobals6 );
			if( !xidf_InitForProcess( 0 ) ){
				return 0L;
			}
			assert( XidfGlobals6 );//*/
		}
		break;
	case DLL_PROCESS_DETACH:{
		}
		break;
	}
	return 1L;
}
