#pragma once
#include "common/IPrefix.h"
//#include "xidf_skse_sdk_fixes_ike9000.h"
#include "skse64/PluginAPI.h"   // SKSEPluginVersionData
#include "skse64_common/skse_version.h"       // What version of SKSE is running?. eg. RUNTIME_VERSION_1_9_32_0
#include "xims_utils.h"
#include <assert.h>
#include "xidf_init.h"

#define XIDF_MOD_NAME "Xinput Modkey SE (SKSE64)"
