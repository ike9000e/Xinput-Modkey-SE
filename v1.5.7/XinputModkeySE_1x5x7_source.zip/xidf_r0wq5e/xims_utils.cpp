#include "xims_utils.h"
#include "common/IPrefix.h"
#include "skse64/GameTypes.h"
#include "skse64_common/skse_version.h"   //CURRENT_RELEASE_SKSE_STR
#include "skse64/PapyrusNativeFunctions.h"
#include <assert.h>
#include <windows.h>
#include "hxdw_utils.h"
#include "xidf_init.h"
#include "xidf_functions.h"

extern XidfGlobals5* XidfGlobals6;

/// Returns pointer pair addressing begin and end of the result nth sub-string.
/// Returns null pointers if failed or bad input index.
std::pair<const char*,const char*>
xims_DelimStrGetNth2( const char* inp, int idxNth, const char* delim )
{
	const char* pos2 = inp, *pos3 = 0;
	int iii = 0;
	for( ; iii < idxNth; iii++ ){
		if( !( pos3 = strstr( pos2, delim ) ) )
			break;
		pos2 = pos3 + strlen( delim );
	}
	if( iii == idxNth ){
		assert(pos2);
		if( !( pos3 = strstr( pos2, delim ) ) )
			pos3 = pos2 + strlen( pos2 );
		return { pos2,  pos3, };
	}
	return { 0, 0,};
}

static BSFixedString
xims_DelimStrGetNth( StaticFunctionTag* base, BSFixedString inp2, SInt32 idxNth2, BSFixedString delim2 )
{
	static std::string outp;
	outp.clear();
	int idxNth = static_cast<int>( idxNth2 );
	assert( idxNth >= 0 );
	const char* inp = inp2.Get();
	const char* delim = delim2.Get();
	assert( inp && delim && *delim );
	auto rs2 = xims_DelimStrGetNth2( inp, idxNth, delim );
	if( rs2.first ){
		assert( rs2.first <= rs2.second );
		outp.assign( rs2.first, rs2.second - rs2.first );
	}
	return BSFixedString( outp.c_str() );
}
static SInt32
xims_DelimStrGetSize( StaticFunctionTag* base, BSFixedString inp2, BSFixedString delim2 )
{
	const char* inp = inp2.Get();
	const char* delim = delim2.Get();
	assert( inp && delim && *delim );
	if( !*inp )
		return 0;
	int ii2 = 1;
	for(; (inp = strstr( inp, delim )); ii2++ )
		inp += strlen(delim);
	return static_cast<SInt32>( ii2 );
}
/// Removes n-th sub-string, character-delimeted.
/// delim2 - string must be 1-character long.
static BSFixedString
xims_DelimStrRemoveNth( StaticFunctionTag* base, BSFixedString inp2, SInt32 idxNth2, BSFixedString delim2 )
{
	static std::string outp;
	outp.clear();
	int idxNth = static_cast<int>( idxNth2 );
	assert( idxNth >= 0 );
	const char* inp = inp2.Get();
	const char* delim = delim2.Get();
	assert( inp && delim && *delim );
	const std::string delim3 = delim;
	assert( delim3.size() == 1 );
	auto rs2 = xims_DelimStrGetNth2( inp, idxNth, delim );
	if( rs2.first ){
		assert( rs2.first <= rs2.second );
		assert( rs2.first >= inp );
		const char* pos2 = strstr( rs2.second, delim );
		if( pos2 == rs2.second )
			rs2.second += strlen( delim );
		outp.assign( inp, rs2.first - inp );
		outp.append( rs2.second );
		{
			std::size_t pos4 = outp.find_last_of( delim3 );
			if( pos4 != std::string::npos && (pos4 + delim3.size()) == outp.size() ){
				std::string::iterator a = outp.end();
				--a;
				outp.erase( a );
			}
		}
		return BSFixedString( outp.c_str() );
	}
	outp = inp;
	return BSFixedString( outp.c_str() );
}

static BSFixedString
xims_ConfGetValue( StaticFunctionTag* base, BSFixedString aSectionName, BSFixedString aKeyName )
{
	assert( XidfGlobals6 );
	static std::string outp;
	XidfGlobals6->readIniFileIfNeeded3();
	outp = XidfGlobals6->ini7->getValue( aSectionName.Get(), aKeyName.Get() );
	return BSFixedString( outp.c_str() );
}
/// Returns nonzero on success. Currently always successfull.
static SInt32
xims_ConfSetValue( StaticFunctionTag* base, BSFixedString aSectionName, BSFixedString aKeyName, BSFixedString aValue )
{
	assert( XidfGlobals6 );
	XidfGlobals6->readIniFileIfNeeded3();
	bool rslt = XidfGlobals6->ini7->setValue( aSectionName.Get(), aKeyName.Get(), aValue.Get() );
	return rslt;
}
/// Returns empty string on success, error message otherwise.
static BSFixedString
xims_ReinitConfiguration( StaticFunctionTag* base, SInt32 dmy0, BSFixedString dmy1 )
{
	auto res2 = xidf_ReinitConfiguration3( "rw" );
	if( !*res2 ){
		static std::string outp;
		outp = res2.second;
		return BSFixedString( outp.c_str() );
	}
	return BSFixedString("");   //success.
}
/**
	Returns key and/or button names.
	\param aFlags - flags as string, eg. "XIMS_Buttons2|XIMS_AllKeys2|Xidf_KT_KeyNamesLong".
*/
static BSFixedString
xims_ConfGetKeyActionNames( StaticFunctionTag* base, BSFixedString aFlags )
{
	static std::string outp;
	outp.clear();
	if( strstr( aFlags.Get(), "XIMS_Buttons2" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetButtonActionNames(',');
	}
	if( strstr( aFlags.Get(), "XIMS_Modkeys2" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetModkeyNames(',');
	}
	if( strstr( aFlags.Get(), "XIMS_AllKeys2" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', 0xFFFFFF );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_KeyNamesLong" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_KeyNamesLong );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_KeyNamesAZ" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_KeyNamesAZ );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_KeyNames0To9" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_KeyNames0To9 );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_KeyNames09Numpad" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_KeyNames09Numpad );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_KeyNamesF1F2Etc" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_KeyNamesF1F2Etc );
	}
	if( strstr( aFlags.Get(), "Xidf_KT_MouseButtonNames" ) ){
		outp += ( !outp.empty() ? "," : "" );
		outp += xidf_GetKeyboardKeyNames(',', Xidf_KT_MouseButtonNames );
	}
	return BSFixedString( outp.c_str() );
}
/**
	Checks other parts of the configuration regarding renaming of a single modkey.
	Returns "1" as first character of the string if rename is ok.

	Otherwise returns delimeter separated string (delim is '/') of 4 sub-strings.
	0: success status; "1": ok, "0": error.
	1: error label text, XIMS_RS_HotkeyInUse2 or XIMS_RS_HotkeyNameExsts2.
	2: a message that can be displayed to the user.
	3: comma separated list, 0-based indexes, of affected routines
		(eg. index zero refers to "[s_routine:0]" section).
*/
static BSFixedString
xims_ConfTestModkeyRename( StaticFunctionTag* base, BSFixedString aOldModkeyName, BSFixedString aNewModkeyName, SInt32 nIndexBase )
{
	assert( XidfGlobals6 );
	static std::string outp;
	std::string srOld = aOldModkeyName.Get(), srNew = aNewModkeyName.Get();
	//if( srOld == srNew_ )
	//	return BSFixedString("1/ok");
	assert( XidfGlobals6->ini7 );
	char bfr[128];
	std::vector<int> aRoutinesAffected;
	std::vector<std::string> aRoutinesAffected2, aHotkeyExistsIfAny;
	XidfGlobals6->ini7->eachVariable( {}, [&]( const char* sec2, const char* varname, const char* val2 )->bool{
			std::vector<std::string> sec0;
			hxdw_StrExplode( sec2, sec0, {":",}, 1, 0 );
			if( sec0.size() >= 2 && sec0[0] == "s_routine" ){
				if( !strcmp( varname, "szHotkey" ) ){
					int nSectionNr = atoi( sec0[1].c_str() );
					std::vector<std::string> parts2;
					hxdw_StrExplode( val2, parts2, {"+",}, -1, 0 );
					for( const auto& a : parts2 ){
						if( !strcmp( a.c_str(), srOld.c_str() ) ){
							aRoutinesAffected.push_back( nSectionNr );
							aRoutinesAffected2.push_back( val2 );
							break;
						}
					}
				}
			}else if( sec0.size() >= 2 && sec0[0] == "s_modkey" ){
				if( !strcmp( varname, "szName" ) ){
					if( !strcmp( val2, srNew.c_str() ) ){
						aHotkeyExistsIfAny.push_back( val2 );
						return 0; // 0: break from the calback.
					}
				}
			}
			return 1;
	});
	if( !aRoutinesAffected.empty() ){
		std::string sr2, sr3;
		for( size_t i=0; i < aRoutinesAffected.size(); i++ ){
			int nRoutineNr     = aRoutinesAffected[i];
			std::string srHotk = aRoutinesAffected2[i];
			sprintf_s( bfr, sizeof(bfr), "%d: [%s]\n", (nRoutineNr + int(nIndexBase)), srHotk.c_str() );
			sr2 += bfr;
			sprintf_s( bfr, sizeof(bfr), "%d,", nRoutineNr );
			sr3 += bfr;
		}
		sr3 = hxdw_TrimStr( sr3, ",", "", -1 );
		outp.clear();
		outp += "0/XIMS_RS_HotkeyInUse2/";
		outp += sr2 + "/";
		outp += sr3;
		return BSFixedString( outp.c_str() );
	}
/*	XidfGlobals6->ini7->eachVariable( {}, [&]( const char* sec2, const char* varname, const char* val2 )->bool{
			std::vector<std::string> sec0;
			hxdw_StrExplode( sec2, sec0, {":",}, 1, 0 );
			if( sec0.size() >= 2 && sec0[0] == "s_modkey" ){
				if( !strcmp( varname, "szName" ) ){
					if( !strcmp( val2, srNew.c_str() ) ){
						aHotkeyExistsIfAny.push_back( sec2 );
						return 0; // 0: break from the calback.
					}
				}
			}
			return 1;
	});//*/
	if( !aHotkeyExistsIfAny.empty() ){
		outp.clear();
		sprintf_s( bfr, sizeof(bfr), "%s", aHotkeyExistsIfAny[0].c_str() );
		outp += "0/XIMS_RS_HotkeyNameExsts2/Same hotkey name already exsts/";
		outp += bfr;
		return BSFixedString( outp.c_str() );
	}
	return BSFixedString("1/ok/ok/ok");
}
std::string xims_GetBuildString2( const char* szEnumType )
{
	std::string outp;
	if( !strcmp( "XIMS_BuildDate2", szEnumType ) ){
		outp = __DATE__;  //eg. "Apr 15 2019"
	}else if( !strcmp( "XIMS_SkseCurrentReleaseStr2", szEnumType ) ){
		outp = CURRENT_RELEASE_SKSE_STR;   // eg. "2.0.15"
	}else if( !strcmp( "XIMS_SkseGameRuntimeVersion2", szEnumType ) ){
		char bfr[128];
		sprintf_s( bfr, sizeof(bfr), "%d.%d.%d",
					GET_EXE_VERSION_MAJOR( CURRENT_RELEASE_RUNTIME ),
					GET_EXE_VERSION_MINOR( CURRENT_RELEASE_RUNTIME ),
					GET_EXE_VERSION_BUILD( CURRENT_RELEASE_RUNTIME ) );
		outp = bfr;  //eg. "1.5.73"
	}else{
		assert(!"Bad enumerated type [mV37TmZdN]");
		outp = "Unknown";
	}
	return outp;
}
static BSFixedString
xims_GetBuildString( StaticFunctionTag* base, BSFixedString aEnumType )
{
	static std::string outp;
	outp = xims_GetBuildString2( aEnumType.Get() );
	return BSFixedString( outp.c_str() );
}

VMResultArray<BSFixedString> xims_MakeArrayOfStrings( StaticFunctionTag*, SInt32 nSize, BSFixedString init2 )
{
	VMResultArray<BSFixedString> rslt;
	rslt.resize( nSize, init2.Get() );
	return rslt;
}//*/
VMResultArray<BSFixedString>
xims_StrExplode( StaticFunctionTag*, BSFixedString inp, BSFixedString delim2,
			SInt32 nLimit, BSFixedString srTrimLR )
{
	VMResultArray<BSFixedString> rslt;
	//std::string str;
	hxdw_StrExplode2( inp.Get(), [&]( const char* sz2, int len ){
		//printf("[%s]\n", std::string( sz2, len).c_str() );
	//	str.assign( sz2, len );
	//	rslt.push_back( BSFixedString( str.c_str() ) );
		rslt.push_back( BSFixedString( std::string(sz2,len).c_str() ) );
		//rslt.emplace_back( BSFixedString( std::string(sz2,len).c_str() ) );
	}, {delim2.Get(),}, (int) nLimit, srTrimLR.Get() );
	return rslt;
}
BSFixedString
xims_StrImplode( StaticFunctionTag*, VMArray<BSFixedString> inp,
				BSFixedString delim2, BSFixedString srTrimLR )
{
	std::string outp;
	const int num = inp.Length();
	for( int i=0; i<num; i++ ){
		BSFixedString str2;
		inp.Get( &str2, i );
		if( !outp.empty() )
			outp += delim2;
		if( *str2.Get() ){
			outp += hxdw_TrimStr( str2.Get(), srTrimLR.Get(), "LR", -1 );
		}else{
			outp += str2.Get();
		}
	}
	return BSFixedString( outp.c_str() );
}
/// Slices array given 0-based index and size.
VMResultArray<BSFixedString>
xims_ArrayStrSlice( StaticFunctionTag*, VMArray<BSFixedString> inp, SInt32 nStartIndex, SInt32 nSize )
{
	assert( nStartIndex >= 0 && nSize >= -1 );
	VMResultArray<BSFixedString> rslt;
	const int num = inp.Length();
	const int endd = ( nSize == -1 ? -1 : nStartIndex + nSize );
	for( int i = nStartIndex; i < num && i != endd; i++ ){
		BSFixedString str2;
		inp.Get( &str2, i );
		rslt.push_back( str2 );
	}
	return rslt;
}
/// Appends one string into the input array of strings and resturns that arrray.
VMResultArray<BSFixedString>
xims_ArrayStrAppend( StaticFunctionTag*, VMArray<BSFixedString> inp, BSFixedString item2 )
{
	VMResultArray<BSFixedString> rslt;
	const int num = inp.Length();
	for( int i = 0; i < num; i++ ){
		BSFixedString str2;
		inp.Get( &str2, i );
		rslt.push_back( str2 );
	}
	rslt.push_back( item2 );
	return rslt;
}
VMResultArray<BSFixedString>
xims_ArrayExtend2( StaticFunctionTag*, VMArray<BSFixedString> inpA, VMArray<BSFixedString> inpB )
{
	VMResultArray<BSFixedString> rslt;
	int num = inpA.Length();
	for( int i = 0; i < num; i++ ){
		BSFixedString str2;
		inpA.Get( &str2, i );
		rslt.push_back( str2 );
	}
	num = inpB.Length();
	for( int i = 0; i < num; i++ ){
		BSFixedString str2;
		inpB.Get( &str2, i );
		rslt.push_back( str2 );
	}
	return rslt;
}
VMResultArray<BSFixedString>
xims_ArrayStrExtendStr( StaticFunctionTag*, BSFixedString strA, BSFixedString strB,
						BSFixedString delim )
{
	VMResultArray<BSFixedString> rslt;
	hxdw_StrExplode2( strA.Get(), [&]( const char* sz2, int len ){
		rslt.push_back( BSFixedString( std::string(sz2,len).c_str() ) );
	}, {delim.Get(),}, -1, nullptr );
	hxdw_StrExplode2( strB.Get(), [&]( const char* sz2, int len ){
		rslt.push_back( BSFixedString( std::string(sz2,len).c_str() ) );
	}, {delim.Get(),}, -1, nullptr );
	return rslt;
}

/**
	Converts given numeric range into array of strings.
	\param srFormat - fprmat for sprintf_s() function,
	                  must be for exactly one argument. Eg. "%d".
*/
VMResultArray<BSFixedString>
xims_RangeToStrNumbers( StaticFunctionTag*, SInt32 nStart, SInt32 nSize, SInt32 nStep,
						BSFixedString srFormat )
{
	VMResultArray<BSFixedString> rslt;
	std::string fmt = srFormat.Get();
	if( fmt.empty() )
		fmt = "%d";
	char bfr[64];
	int nmbr = nStart;
	for( int i = 0; i < nSize; i++, nmbr += nStep ){
		sprintf_s( bfr, sizeof(bfr), fmt.c_str(), nmbr );
		rslt.push_back( BSFixedString(bfr) );
	}
	return rslt;
}

bool xims_RegisterFuncs( VMClassRegistry* registry3 )
{
	{
		IFunction* lpFunc2 = new NativeFunction2<
				StaticFunctionTag, BSFixedString, SInt32, BSFixedString >(
				"xims_ReinitConfiguration", "XinputModkeySeMcmByIkk",
				xims_ReinitConfiguration, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}
	{
		IFunction* lpFunc3 = new NativeFunction3<
				StaticFunctionTag, BSFixedString, BSFixedString, SInt32, BSFixedString >(
				"xims_DelimStrGetNth", "XinputModkeySeMcmByIkk",
				xims_DelimStrGetNth, registry3 );
		registry3->RegisterFunction( lpFunc3 );
	}
	{
		IFunction* lpFunc4 = new NativeFunction2<
				StaticFunctionTag, SInt32, BSFixedString, BSFixedString >(
				"xims_DelimStrGetSize", "XinputModkeySeMcmByIkk",
				xims_DelimStrGetSize, registry3 );
		registry3->RegisterFunction( lpFunc4 );
	}
	{
		IFunction* lpFunc5 = new NativeFunction3<
				StaticFunctionTag, BSFixedString, BSFixedString, SInt32, BSFixedString >(
				"xims_DelimStrRemoveNth", "XinputModkeySeMcmByIkk",
				xims_DelimStrRemoveNth, registry3 );
		registry3->RegisterFunction( lpFunc5 );
	}
	{
		IFunction* lpFunc2 = new NativeFunction2<
				StaticFunctionTag, BSFixedString, BSFixedString, BSFixedString >(
				"xims_ConfGetValue", "XinputModkeySeMcmByIkk",
				xims_ConfGetValue, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}
	{
		IFunction* lpFunc2 = new NativeFunction3<
				StaticFunctionTag, SInt32, BSFixedString, BSFixedString, BSFixedString >(
				"xims_ConfSetValue", "XinputModkeySeMcmByIkk",
				xims_ConfSetValue, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}
	{
		IFunction* lpFunc2 = new NativeFunction1<
				StaticFunctionTag, BSFixedString, BSFixedString>(
				"xims_ConfGetKeyActionNames", "XinputModkeySeMcmByIkk",
				xims_ConfGetKeyActionNames, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}
	{
		IFunction* lpFunc2 = new NativeFunction3<
				StaticFunctionTag, BSFixedString, BSFixedString, BSFixedString, SInt32>(
				"xims_ConfTestModkeyRename", "XinputModkeySeMcmByIkk",
				xims_ConfTestModkeyRename, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}
	{
		IFunction* lpFunc2 = new NativeFunction1<
				StaticFunctionTag, BSFixedString, BSFixedString>(
				"xims_GetBuildString", "XinputModkeySeMcmByIkk",
				xims_GetBuildString, registry3 );
		registry3->RegisterFunction( lpFunc2 );
	}{
		registry3->RegisterFunction(
			new NativeFunction4< StaticFunctionTag,
				VMResultArray<BSFixedString>, BSFixedString, BSFixedString, SInt32, BSFixedString>(
					"xims_StrExplode", "XinputModkeySeMcmByIkk",
					xims_StrExplode, registry3 ) );
		registry3->RegisterFunction(
			new NativeFunction3< StaticFunctionTag, BSFixedString,
				VMArray<BSFixedString>, BSFixedString, BSFixedString>(
					"xims_StrImplode", "XinputModkeySeMcmByIkk",
					xims_StrImplode, registry3 ) );
	}{
		registry3->RegisterFunction(
			new NativeFunction4< StaticFunctionTag,
				VMResultArray<BSFixedString>, SInt32, SInt32, SInt32, BSFixedString>(
					"xims_RangeToStrNumbers", "XinputModkeySeMcmByIkk",
					xims_RangeToStrNumbers, registry3 ) );
	}
	{
		registry3->RegisterFunction(
			new NativeFunction2< StaticFunctionTag,
				VMResultArray<BSFixedString>, SInt32, BSFixedString>(
					"xims_MakeArrayOfStrings", "XinputModkeySeMcmByIkk",
					xims_MakeArrayOfStrings, registry3 ) );
		registry3->RegisterFunction(
			new NativeFunction3< StaticFunctionTag,
				VMResultArray<BSFixedString>, BSFixedString, BSFixedString, BSFixedString>(
					"xims_ArrayStrExtendStr", "XinputModkeySeMcmByIkk",
					xims_ArrayStrExtendStr, registry3 ) );
		registry3->RegisterFunction(
			new NativeFunction3< StaticFunctionTag,
				VMResultArray<BSFixedString>, VMArray<BSFixedString>, SInt32, SInt32>(
					"xims_ArrayStrSlice", "XinputModkeySeMcmByIkk",
					xims_ArrayStrSlice, registry3 ) );
		registry3->RegisterFunction(
			new NativeFunction2< StaticFunctionTag,
				VMResultArray<BSFixedString>, VMArray<BSFixedString>, BSFixedString>(
					"xims_ArrayStrAppend", "XinputModkeySeMcmByIkk",
					xims_ArrayStrAppend, registry3 ) );
		registry3->RegisterFunction(
			new NativeFunction2< StaticFunctionTag,
				VMResultArray<BSFixedString>, VMArray<BSFixedString>, VMArray<BSFixedString>>(
					"xims_ArrayExtend2", "XinputModkeySeMcmByIkk",
					xims_ArrayExtend2, registry3 ) );
	}
	return 1;
}







