#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1
#include <string>
struct hxdw_IniData2;

/// Basic quad implementation. Inspired by std::pair.
template<class Txx, class Uxx, class Vxx = char, class Xxx = char>
struct XidfQuad2{
	Txx first;
	Uxx second;
	Vxx third;
	Xxx fourth;
	;          XidfQuad2( const Txx& a, const Uxx& b, const Vxx& c = {}, const Xxx& d = {} ) : first(a), second(b), third(c), fourth(d) {}
	;          XidfQuad2() = default;
	const Txx& operator*()const {return first;}
	Txx&       operator*()      {return first;}
	const Uxx& operator+()const {return second;}
	Uxx&       operator+()      {return second;}
};

bool xidf_InitForProcess( void* hInstance ); //HINSTANCE
void xidf_DeinitForProcess();
bool xidf_InitGlobalData( void* hInstance ); //HINSTANCE
bool xidf_ReinitConfiguration2( const hxdw_IniData2& ini_, std::string* err2 = 0 );
auto xidf_ReinitConfiguration3( const char* flags2 ) -> XidfQuad2<bool,std::string>;
auto xidf_GetCurrentConfigFileName() -> const char*;
long xidf_CreateEnabledMHDetour( void* pAddress, void** ppOrigCall, void* pDetour, bool bCreateEnabled );


