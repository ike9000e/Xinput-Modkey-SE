#pragma once
#include <string>
//#include "skse64/PapyrusNativeFunctions.h"
//#include "common/IPrefix.h"
//#include "xidf_skse_sdk_fixes_ike9000.h"
// /FI ../../source/xidf_r0wq5e/skse_sdk_fixes_ike9000.h
class  VMClassRegistry;
struct hxdw_IniData2;

bool xims_RegisterFuncs( VMClassRegistry* registry );
auto xims_GetBuildString2( const char* szEnumType ) -> std::string;
