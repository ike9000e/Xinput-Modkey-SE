#include "xims_skse64_cpp_files.h"

//{
#if defined(skse64_2_02_02_gog)

#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/GameAPI.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/GameTypes.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/GameUtilities.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/PapyrusArgs.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/PapyrusInterfaces.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64/PapyrusVM.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_02_gog/src/skse64/skse64_common/Relocation.cpp"

#elif defined(skse64_2_00_20_se)

#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/GameAPI.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/GameTypes.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/GameUtilities.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/PapyrusArgs.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/PapyrusInterfaces.cpp"
//#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/PapyrusNativeFunctions.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/PapyrusVM.cpp"
//#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64/PapyrusValue.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_00_20_se/src/skse64/skse64_common/Relocation.cpp"

#elif defined(skse64_2_02_06_ae)

#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/GameAPI.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/GameTypes.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/GameUtilities.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/PapyrusArgs.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/PapyrusInterfaces.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/PapyrusNativeFunctions.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/PapyrusVM.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64/PapyrusValue.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_ae/src/skse64/skse64_common/Relocation.cpp"
//*/

#elif defined(skse64_2_02_06_gog)

#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/GameAPI.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/GameTypes.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/GameUtilities.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/PapyrusArgs.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/PapyrusInterfaces.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/PapyrusNativeFunctions.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/PapyrusVM.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64/PapyrusValue.cpp"
#	include "./../../libraries_1/skse_sdk/skse64_2_02_06_gog/src/skse64/skse64_common/Relocation.cpp"

#else
#	error "Unknown build mode for SKSE64 [6GwI2w]"
#endif
//}
