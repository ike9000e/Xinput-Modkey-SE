#include "xidf_functions.h"
#include <assert.h>
#include <algorithm>
#include <process.h>    //_getpid()
#include <cctype>       //std::isalpha()

XidfGlobals5* XidfGlobals6 = nullptr;

//DWORD WINAPI xidf_XInputGetKeystroke( DWORD dwUserIndex, DWORD dwReserved, void* pKeystroke )
//{
//	assert(0);
//	return 00;
//}

const std::vector<std::pair<int,int> > xidf_ButtonBits = {
	{ Xidf_Act_A, XINPUT_GAMEPAD_A,},
	{ Xidf_Act_B, XINPUT_GAMEPAD_B,},
	{ Xidf_Act_X, XINPUT_GAMEPAD_X,},
	{ Xidf_Act_Y, XINPUT_GAMEPAD_Y,},
	{ Xidf_Act_UP, XINPUT_GAMEPAD_DPAD_UP,},
	{ Xidf_Act_DOWN, XINPUT_GAMEPAD_DPAD_DOWN,},
	{ Xidf_Act_LEFT, XINPUT_GAMEPAD_DPAD_LEFT,},
	{ Xidf_Act_RIGHT, XINPUT_GAMEPAD_DPAD_RIGHT,},
	{ Xidf_Act_START, XINPUT_GAMEPAD_START,},
	{ Xidf_Act_BACK, XINPUT_GAMEPAD_BACK,},
	{ Xidf_Act_LS, XINPUT_GAMEPAD_LEFT_SHOULDER,},
	{ Xidf_Act_RS, XINPUT_GAMEPAD_RIGHT_SHOULDER,},
	{ Xidf_Act_LT, XINPUT_GAMEPAD_LEFT_THUMB,},
	{ Xidf_Act_RT, XINPUT_GAMEPAD_RIGHT_THUMB,},
};
const std::vector<int> xidf_ActionIsStick = {
	Xidf_Act_LSXAdd, Xidf_Act_LSXSub,
	Xidf_Act_LSYAdd, Xidf_Act_LSYSub,
	Xidf_Act_RSXAdd, Xidf_Act_RSXSub,
	Xidf_Act_RSYAdd, Xidf_Act_RSYSub,
};
const std::vector<int> xidf_ActionIsTrigger = {
	Xidf_Act_LTr, Xidf_Act_RTr,
};
const std::vector<std::pair<int,std::string> > xidf_ActNames = {
	{ Xidf_Act_A, "A", },
	{ Xidf_Act_B, "B", },
	{ Xidf_Act_X, "X", },
	{ Xidf_Act_Y, "Y", },
	{ Xidf_Act_LT, "LTh", },  // Left Thumbstick.
	{ Xidf_Act_RT, "RTh", },
	{ Xidf_Act_START, "START", },
	{ Xidf_Act_BACK, "BACK", },
	{ Xidf_Act_UP, "UP", },
	{ Xidf_Act_DOWN, "DOWN", },
	{ Xidf_Act_LEFT, "LEFT", },
	{ Xidf_Act_RIGHT, "RIGHT", },
	{ Xidf_Act_LS, "LSh", },
	{ Xidf_Act_RS, "RSh", },
	{ Xidf_Act_LTr, "LTr", },  // Left Trigger.
	{ Xidf_Act_RTr, "RTr", },
	{ Xidf_Act_LSXAdd, "LSXPlus", },
	{ Xidf_Act_LSXSub, "LSXMinus", },
	{ Xidf_Act_LSYAdd, "LSYPlus", },
	{ Xidf_Act_LSYSub, "LSYMinus", },
	{ Xidf_Act_RSXAdd, "RSXPlus", },
	{ Xidf_Act_RSXSub, "RSXMinus", },
	{ Xidf_Act_RSYAdd, "RSYPlus", },
	{ Xidf_Act_RSYSub, "RSYMinus", },
};
/// Mouse button flags used by Winapi SendInput(), MOUSEINPUT and INPUT.
const std::vector< std::pair< int, std::pair<int,int> > >  xidf_MButtonBits = {
	{ 1, { MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,},},
	{ 2, { MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP,},},
	{ 3, { MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP,},},
	//MOUSEEVENTF_WHEEL
};
const std::vector<std::pair<int,std::string> > xidf_TINames = {
	{ Xidf_TI_MouseMove, "eMouseMotion", },
	{ Xidf_TI_KbdArrows, "eKbdArrows", }, //WIP.
};
const std::vector<std::pair<int, std::vector<std::string> > > xidf_KeyNames = {
	{ VK_BACK, {"backspace","bs","back",}, },
	{ VK_TAB, {"tab",}, },
	{ VK_CLEAR, {"CLEAR",}, },
	{ VK_RETURN, {"RETURN","ENTER",}, },
	{ VK_SHIFT, {"SHIFT",}, },
	{ VK_CAPITAL, {"Capital","CapsLock",}, },
	{ VK_ESCAPE, {"Esc","Escape",}, },
	{ VK_PRIOR, {"PRIOR","PageUp","PgUp",}, },
	{ VK_NEXT, {"NEXT","PageDown","PgDn",}, },

	{ VK_LEFT, {"LeftArrow","LEFT","LArrow",}, },
	{ VK_UP, {"UpArrow","UP","UArrow",}, },
	{ VK_RIGHT, {"RightArrow","RIGHT","RArrow",}, },
	{ VK_DOWN, {"DownArrow","DOWN","DArrow",}, },

	{ VK_SNAPSHOT, {"SNAPSHOT","PrintScreen","PrntScr"}, },
	{ VK_LWIN, {"LWIN","WIN",}, },
	{ VK_RWIN, {"RWIN",}, },
	{ VK_APPS, {"APPS","Applications",}, },
	{ VK_MULTIPLY, {"MULTIPLY","Mul",}, },
	{ VK_NUMLOCK, {"NumLock",}, },
	{ VK_SCROLL, {"SCROLL","ScrollLock",}, },
	{ VK_CONTROL, {"CONTROL","Ctrl",}, },
	{ VK_MENU, {"MENU","ALT",}, },
	{ VK_PAUSE, {"Pause",}, },
	{ VK_SPACE, {"Space",}, },
	{ VK_END, {"END",}, },
	{ VK_HOME, {"HOME",}, },
	{ VK_SELECT, {"SELECT",}, },
	{ VK_EXECUTE, {"EXECUTE",}, },
	{ VK_INSERT, {"INSERT",}, },
	{ VK_DELETE, {"DELETE",}, },
	{ VK_HELP, {"HELP",}, },
	{ VK_ADD, {"ADD",}, },
	{ VK_SEPARATOR, {"SEPARATOR",}, },
	{ VK_SUBTRACT, {"SUBTRACT","Sub",}, },
	{ VK_DECIMAL, {"DECIMAL",}, },
	{ VK_DIVIDE, {"DIVIDE","Div",}, },
	{ VK_ATTN, {"ATTN",}, },
	{ VK_CRSEL, {"CRSEL",}, },
	{ VK_EXSEL, {"EXSEL",}, },
	{ VK_EREOF, {"EREOF",}, },
	{ VK_PLAY, {"PLAY",}, },
	{ VK_ZOOM, {"ZOOM",}, },
};
/// Pairs of analogue inputs that correspond to all 4 diagonal directions (2 sticks).
const std::vector<std::array<int,2> > xidf_ActnAnaglogueDrctnPairs = {
	// on left stick
	{ Xidf_Act_LSXAdd, Xidf_Act_LSYAdd,},  //east-north
	{ Xidf_Act_LSXAdd, Xidf_Act_LSYSub,},  //east-south
	{ Xidf_Act_LSXSub, Xidf_Act_LSYSub,},  //west-south
	{ Xidf_Act_LSXSub, Xidf_Act_LSYAdd,},  //west-north
	// on ritght stick
	{ Xidf_Act_RSXAdd, Xidf_Act_RSYAdd,},  //east-north
	{ Xidf_Act_RSXAdd, Xidf_Act_RSYSub,},  //east-south
	{ Xidf_Act_RSXSub, Xidf_Act_RSYSub,},  //west-south
	{ Xidf_Act_RSXSub, Xidf_Act_RSYAdd,},  //west-north
};

int xidf_StrToTrInputMode( const char* inp )
{
	for( const auto& a : xidf_TINames ){
		if( a.second == inp )
			return a.first;  //eg. Xidf_TI_MouseMove
	}
	return 0;
}
void xidf_MsgBoxIf( HWND hwnd, const char* msg, const char* flags2 )
{
	assert( XidfGlobals6 );
	if( XidfGlobals6->bCLIOnly )
		return;
	bool bErr = !strchr( flags2, 'k' );
	MessageBox( hwnd, msg, "XIDF", (bErr?MB_ICONERROR:0) );
}
XINPUT_GAMEPAD
xidf_EnforceAPIDeadZones( const XINPUT_GAMEPAD& gp2_, bool bReinterpolate )
{
	XINPUT_GAMEPAD gp2 = gp2_;
	const int deadzoneLStk = XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE; //7849
	const int deadzoneRStk = XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE; //8689
	const int deadzoneTrg  = XINPUT_GAMEPAD_TRIGGER_THRESHOLD; //30
	const bool bRi = bReinterpolate;
	gp2.bLeftTrigger  = xidf_ApplyDeadZoneIfNeeded( gp2.bLeftTrigger, deadzoneTrg, (bRi ? Xidf_MaxTriggerPos : 0) );
	gp2.bRightTrigger = xidf_ApplyDeadZoneIfNeeded( gp2.bRightTrigger, deadzoneTrg, (bRi ? Xidf_MaxTriggerPos : 0) );
	//float magnitude2 = sqrt( pow( gp2.sThumbLX, 2 ) + pow( gp2.sThumbLY, 2 ) );
	gp2.sThumbLX = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbLX, deadzoneLStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbLY = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbLY, deadzoneLStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbRX = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbRX, deadzoneRStk, (bRi ? Xidf_MaxStickPos : 0) );
	gp2.sThumbRY = xidf_ApplyDeadZoneIfNeeded( gp2.sThumbRY, deadzoneRStk, (bRi ? Xidf_MaxStickPos : 0) );
	return gp2;
}
int xidf_StrToGamepadAction( const char* inp )
{
	int outp = 0;
	std::find_if( xidf_ActNames.begin(), xidf_ActNames.end(),
			[&]( const std::pair<int,std::string>& a ){
					if( !lstrcmpi( a.second.c_str(), inp ) ){
						outp = a.first;
						return 1;
					}
					return 0;
			}
	);
	return outp;
}
bool xidf_ParseRoutines( const hxdw_IniData2& ini4, std::vector<Xidf_Routine>& actionsOu, std::string* err2 )
{
	char bfr[512]; bool bSucc = 1;
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn = hxdw_TrimStr("s_routine:0", ":0", "R", -1 );
	ini4.eachSection( [&]( const hxdw_IniSection& sec2 ){
			std::string secname = sec2.first;
			if( secname.size() > srSecNameBgn.size() )
				secname = secname.substr( 0, srSecNameBgn.size() );
			if( secname == srSecNameBgn ){
				const bool bRDisabled = !!atoi( ini4.getValue( sec2.first.c_str(), "bRDisabled" ).c_str() );
				std::string srHotk = ini4.getValue( sec2.first.c_str(), "szHotkey" );
			/*	if( srHotk.empty() && !bRDisabled ){
					sprintf_s( bfr, sizeof(bfr),
							"No trigger specified for action [%s]",
							sec2.first.c_str() );
					err3 = bfr; bSucc = 0;
					return 0;
				}//*/
				Xidf_Trigger trgr;
				if( !srHotk.empty() ){
					if( !xidf_ParseTriggerSequence( srHotk.c_str(), trgr, &err3, "" ) ){
						sprintf_s( bfr, sizeof(bfr),
								"Failed parsing trigger for action [%s].szHotkey [%s]",
								sec2.first.c_str(), err3.c_str() );
						err3 = bfr; bSucc = 0;
						return 0;
					}
				}
				std::string vSprss = ini4.getValue( sec2.first.c_str(), "szSuppress" );
				std::string vHold = ini4.getValue( sec2.first.c_str(), "szHold" );
				std::string vSndk = ini4.getValue( sec2.first.c_str(), "szSendKeys" );
				std::string vAutoRepeat = ini4.getValue( sec2.first.c_str(), "szAutoRepeat" );
				std::string vRescaleThese = ini4.getValue( sec2.first.c_str(), "fRescaleThese" );
				const bool bNoDiagonalAdjust2 = !!atoi( ini4.getValue( sec2.first.c_str(), "bNoDiagonalAdjust2", "0" ).c_str() );
				Xidf_Routine rtne3;
				rtne3.bRDisabled = bRDisabled;
				rtne3.trigger2 = trgr;
				xidf_ActionsToArray( vSprss.c_str(), ',', rtne3.aSuppress, &err3 );
				if( !vHold.empty() ){
					if( !xidf_StrToInputList( vHold.c_str(), ',', rtne3.aHold2, &err3 ) ){
						sprintf_s( bfr, sizeof(bfr),
								"Error at [%s].szHold [%s]",
								sec2.first.c_str(), err3.c_str() );
						err3 = bfr; bSucc = 0;
						return 0;
					}
				}
				rtne3.bHExclusive = !!atoi( ini4.getValue( sec2.first.c_str(), "bHExclusive" ).c_str() );
				{
					std::vector<std::string> vcodes2;
					hxdw_StrExplode( vSndk.c_str(), vcodes2, {",",}, -1, "\x20\t" );
					for( const auto& srVk : vcodes2 ){
						if( !srVk.empty() && srVk[0] == 'm' ){ // eg. "m1", "m2" or "m3".
							Xidf_SendKey sn2( 0, ++XidfGlobals6->nLastSendkId );
							sn2.nMouseBtn = atoi( srVk.substr(1).c_str() );
							rtne3.aSendVk.push_back( sn2 );
						}else{
							rtne3.aSendVk.push_back( Xidf_SendKey(
									atoi( srVk.c_str() ), ++XidfGlobals6->nLastSendkId ) );
						}
					}
				}
				if( !vAutoRepeat.empty() ){
					std::vector<std::string> parts2;
					std::vector<uint64_t> parts3;
					hxdw_StrExplode( vAutoRepeat.c_str(), parts2, {",",}, -1, "\x20\t" );
					for( const auto& a : parts2 ){
						parts3.push_back( std::abs( atoi(a.c_str()) ) * 1000 );
					}
					if( !parts3.empty() && parts3[0] ){
						parts3.resize( 2, parts3[0] );
						rtne3.eSimMode = Xidf_SM_Autorepeat;
						rtne3.turbo2 = Xidf_AutoRepeat( parts3[0], parts3[1] );
					}
				}
				if( !vRescaleThese.empty() ){
					std::vector<std::string> parts2;
					hxdw_StrExplode( vRescaleThese.c_str(), parts2, {",",}, 2, "\r\n\x20\t" );
					if( parts2.size() >= 3 ){
						rtne3.fRescaleThese.fScale = (float)atof( parts2[0].c_str() );
						rtne3.fRescaleThese.eType2 = ( parts2[1].empty() ? '=' : parts2[1][0] );
						std::vector<int>& arr2 = rtne3.fRescaleThese.aActions;
						if( !xidf_ActionsToArray( parts2[2].c_str(), ',', arr2, &err3 ) ){
							sprintf_s( bfr, sizeof(bfr),
								"Failed parsing gamepad action names, [%s].fRescaleThese. [%s]",
								sec2.first.c_str(), err3.c_str() );
							err3 = bfr; bSucc = 0;
							return 0;
						}
					}
					rtne3.fRescaleThese.bNoDiagonalAdjust2 = bNoDiagonalAdjust2;
				}
				actionsOu.push_back( rtne3 );
			}
			return 1;
	});
	return bSucc;
}

bool
xidf_ParseTriggerSequence( const char* inp, Xidf_Trigger& outp, std::string* err2, const char* flags2 )
{
	//flags2
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btnsOrMdk;
	hxdw_StrExplode( inp, btnsOrMdk, {"+",}, -1, "\x20\t" );
	if( btnsOrMdk.empty() || btnsOrMdk[0].empty() ){
		err3 = "No modkey name.";
		return 0;
	}
	for( const auto& a : btnsOrMdk ){
		int id2;
		if( (id2 = xidf_FindModkeyByName( a.c_str(), XidfGlobals6->modkeys3 )) ){
			outp.modkeyIds.push_back( id2 );
			outp.order2.push_back( { (outp.modkeyIds.size()-1), 1,} );
		}else if( (id2 = xidf_StrToGamepadAction( a.c_str() )) ){
			outp.buttons2.push_back( id2 );
			outp.order2.push_back( { (outp.buttons2.size()-1), 0,} );
		}else{
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Trigger item '%s' not recognizaed. "
					"It must be either modkey name or button name.",
					a.c_str() );
			err3 = bfr;
			return 0;
		}
	}
	outp.ident4 = ++XidfGlobals6->nLastTriggerId;
	return 1;
}
bool xidf_ActionsToArray( const char* szBtnNames, char glue2, std::vector<int>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btns;
	hxdw_StrExplode( szBtnNames, btns, { std::string(&glue2,1),}, -1, "\x20\t" );
	for( const auto& a : btns ){
		int id2;
		if( !(id2 = xidf_StrToGamepadAction( a.c_str() )) ){
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr),
					"Unrecognizaed action name '%s'.", a.c_str() );
			err3 = bfr;
			return 0;
		}
		outp.push_back(id2);
	}
	return 1;
}
bool xidf_ParseModkeys2( const hxdw_IniData2& ini5, std::vector<Xidf_Modkey>& modkeysOu, std::string* err2 )
{
	char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::string srSecNameBgn2 = hxdw_TrimStr("s_modkey:0", ":0", "R", -1 );
	std::vector<std::string> secnames;
	//ini5.getSectionsByNamePrefix()
	ini5.eachSection( [&]( const hxdw_IniSection& sec ){
			std::string secnme( sec.first );
			if( secnme.size() > srSecNameBgn2.size() )
				secnme = secnme.substr( 0, srSecNameBgn2.size() );
			if( secnme == srSecNameBgn2 )
				secnames.push_back( sec.first );
			return 1;
	});
	int nNr = 0;
	std::vector<std::string>::const_iterator a;
	for( a = secnames.begin(); a != secnames.end(); ++a, nNr++ ){
		std::string sname = *a;
		Xidf_Modkey mdk0;
		std::string srBtn    = ini5.getValue( sname.c_str(), "szButton" );
		std::string srThrsh  = ini5.getValue( sname.c_str(), "nFloor" );
		std::string srLimit  = ini5.getValue( sname.c_str(), "nCeil" );
		std::string srRename = ini5.getValue( sname.c_str(), "szName" );
	//	std::string srRescale = ini5.getValue( sname.c_str(), "fMRescaleOutput" );
		mdk0.bMDisabled = !!atoi( ini5.getValue( sname.c_str(), "bMDisabled" ).c_str() );
		if( srBtn.empty() ){
			sprintf_s( bfr, sizeof(bfr), "Empty button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.btnActivator = xidf_StrToGamepadAction( srBtn.c_str() );
		if( !mdk0.btnActivator ){
			sprintf_s( bfr, sizeof(bfr), "Unknown button name, [%s].szButton", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		mdk0.threshold2 = ( srThrsh.empty() ? -1 : xidf_StrToLimit( srThrsh.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( srLimit.empty() ? -1 : xidf_StrToLimit( srLimit.c_str(), mdk0.btnActivator ) );
		mdk0.limit2 = ( !mdk0.limit2 ? -1 : mdk0.limit2 );

		if( !srRename.empty() ){
			mdk0.rename2 = srRename;
		}else{
			sprintf_s( bfr, sizeof(bfr), "Mod%d", nNr );
			mdk0.rename2 = bfr;
		}
		//if( !srRescale.empty() ){
			//mdk0.fMRescale.first = atof( srRescale.c_str() );
			//const char* sz2 = strchr( srRescale.c_str(), ',' );
			//mdk0.fMRescale.second = atoi( ( sz2 ? &sz2[1] : "0" ) );
		//}
		mdk0.bSuppress = !!atoi( ini5.getValue( sname.c_str(), "bSuppress" ).c_str() );
		mdk0.ident3    = ++XidfGlobals6->nLastModkId;

		modkeysOu.push_back( mdk0 );
	}
	return 1;
}
bool xidf_IsGamepadStickAction( int eAction )
{
	for( const auto& a : xidf_ActionIsStick ){
		if( a == eAction )
			return 1;
	}
	return 0;
}
bool xidf_IsGamepadTriggerAction( int eAction )
{
	for( const auto& a : xidf_ActionIsTrigger ){
		if( a == eAction )
			return 1;
	}
	return 0;
}

/// If found, returns nonzero value epresenting mask|bit of the digital
/// gamepad button.
int xidf_ActionToBitIfAny( int eBtn )
{
	for( const auto& a : xidf_ButtonBits ){
		if( a.first == eBtn )
			return a.second;
	}
	return 0;
}
std::pair<int,float>
xidf_GetInputValueForAction( int eAction, const XINPUT_GAMEPAD& gpd )
{
	int mask2 = xidf_ActionToBitIfAny( eAction );
	if( mask2 ){
		return ( gpd.wButtons & mask2 ? std::make_pair(1,1.f) : std::make_pair(0,0.f) );
	}
	if( 0 ){
	}else if( eAction == Xidf_Act_LTr ){
		return { gpd.bLeftTrigger, ( float(gpd.bLeftTrigger) / Xidf_MaxTriggerPos ), };
	}else if( eAction == Xidf_Act_RTr ){
		return { gpd.bRightTrigger, ( float(gpd.bRightTrigger) / Xidf_MaxTriggerPos ), };

	}else if( eAction == Xidf_Act_LSXAdd && gpd.sThumbLX >= 0 ){
		return { gpd.sThumbLX, ( float(gpd.sThumbLX) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_LSXSub && gpd.sThumbLX < 0 ){
		int val = std::abs( gpd.sThumbLX );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_LSYAdd && gpd.sThumbLY >= 0 ){
		return { gpd.sThumbLY, ( float(gpd.sThumbLY) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_LSYSub && gpd.sThumbLY < 0 ){
		int val = std::abs( gpd.sThumbLY );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_RSXAdd && gpd.sThumbRX >= 0 ){
		return { gpd.sThumbRX, ( float(gpd.sThumbRX) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_RSXSub && gpd.sThumbRX < 0 ){
		int val = std::abs( gpd.sThumbRX );
		return { val, ( float(val) / Xidf_MaxStickPos ), };

	}else if( eAction == Xidf_Act_RSYAdd && gpd.sThumbRY >= 0 ){
		return { gpd.sThumbRY, ( float(gpd.sThumbRY) / Xidf_MaxStickPos ), };
	}else if( eAction == Xidf_Act_RSYSub && gpd.sThumbRY < 0 ){
		int val = std::abs( gpd.sThumbRY );
		return { val, ( float(val) / Xidf_MaxStickPos ), };
	}
	return {0,0.0f,};
}
bool xidf_TestActionDown( int eActnn2, std::pair<int,int> aRangeFloorCeil, const XINPUT_GAMEPAD& gpd )
{
	const int threshold3 = aRangeFloorCeil.first;
	const int ceil2      = aRangeFloorCeil.second;
	const int poss       = xidf_GetInputValueForAction( eActnn2, gpd ).first;
	if( poss && poss >= threshold3 ){
		if( ceil2 == -1 || poss < ceil2 )
			return 1;
	}
	return 0;
}
Xidf_ModkeyDown* Xidf_ModkeyDown::findModkey( int ident, Xidf_ModkeyDown* inp, size_t num )
{
	for( int i=0; i<num; i++ ){
		if( inp[i].mod2->ident3 == ident )
			return &inp[i];
	}
	return 0;
}
/**
	Checks if action is down.
	\param eAction - gamepad action, eg. \ref Xidf_Act_LSXAdd.
	\param aRange - range as decimal values, analogue inputs only.
	                if 'first' is set to -1 then tries to use default deadzone for the input.
	                if 'second' is set to -1 then there is no upper limit check
	                for the action.
*/
bool xidf_IsActionDown( int eAction, const XINPUT_GAMEPAD& gpd, std::pair<int,int> aRange )
{
	if( xidf_IsGamepadStickAction( eAction ) || xidf_IsGamepadTriggerAction( eAction ) ){
		if( aRange.first == -1 )
			aRange.first = std::max<int>( 0, xidf_GetThresholdForActionIfAny( eAction ) );
		return xidf_TestActionDown( eAction, aRange, gpd );
	}else{
		int flg = xidf_ActionToBitIfAny( eAction );
		if( flg & gpd.wButtons )
			return 1L;
	}
	return 0L;
}
int xidf_GetThresholdForActionIfAny( int eBtn )
{
	const auto a = std::find( xidf_ActionIsStick.begin(), xidf_ActionIsStick.end(), eBtn );
	if( a != xidf_ActionIsStick.end() ){
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
		return XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;
	}
	const auto b = std::find( xidf_ActionIsTrigger.begin(), xidf_ActionIsTrigger.end(), eBtn );
	if( b != xidf_ActionIsTrigger.end() ){
		return XINPUT_GAMEPAD_TRIGGER_THRESHOLD;
	}
	return -1;
}
bool xidf_PerformModkeys( Xidf_Perform& inp )
{
	//if( XidfGlobals6->bInited && inp.dwUserIndex2 == XidfGlobals6->nGamepadIndex ){}
	if( XidfGlobals6->bInited ){
		const XINPUT_GAMEPAD  gpd  = inp.xistate.Gamepad;//xidf_EnforceAPIDeadZones()
		XINPUT_GAMEPAD        gpd2 = inp.xistate.Gamepad;
		if( XidfGlobals6->bEnforceAPIDeadzones ){
			gpd2 = xidf_EnforceAPIDeadZones( gpd2, XidfGlobals6->bADZReinterpolate );
		}
		for( const int a : XidfGlobals6->aGlobSuppr ){
			xidf_SetGamepadValueInt( a, 0, gpd2 );
		}
		for( auto& a : XidfGlobals6->aModsDown ){ // Xidf_ModkeyDown, Xidf_Modkey
			if( a.mod2->bMDisabled )
				continue;
			bool bDown3 = xidf_IsActionDown( a.mod2->btnActivator, gpd, { a.mod2->threshold2, a.mod2->limit2,} );
			if( a.bDown2 && !bDown3 ){
				a.bDown2 = 0; //printf("--- modk up!\n");
			}else if( !a.bDown2 && bDown3 ){
				a.bDown2 = 1; //printf("--- modk down!\n");
			}
			if( a.mod2->bSuppress ){
				xidf_SetGamepadValueInt( a.mod2->btnActivator, 0, gpd2 );
			}
		}
		for( auto& a : XidfGlobals6->aRoutinesLive ){
			if( a.routine2->bRDisabled )
				continue;
			std::vector<int> aBtnsDownPerActn;
			bool bLive2 = xidf_IsRtneTriggerDown( a.routine2->trigger2, gpd, &aBtnsDownPerActn );
			if( a.routine2->bHExclusive ){
				for( const auto& b : xidf_ActNames ){
					const auto c = std::find( aBtnsDownPerActn.begin(), aBtnsDownPerActn.end(), b.first );
					if( c == aBtnsDownPerActn.end() ){
						if( xidf_IsActionDown( b.first, gpd, {-1,-1,} ) ){
							bLive2 = 0;
							break;
						}
					}
				}
			}
			if( !a.bLive && bLive2 ){
				a.bLive = 1; //printf("--- act down.\n");
				xidf_RoutineLiveOnDown( a, inp, gpd, gpd2 );
			}else if( a.bLive && !bLive2 ){
				a.bLive = 0; //printf("--- act up.\n");
				xidf_RoutineLiveOnUp( a, inp, gpd, gpd2 );
			}
			if( a.bLive ){
				xidf_RoutineLivePerform( a, inp, gpd, gpd2 );
			}
		}
		for( auto& a : XidfGlobals6->aTrInputLive ){
			//aTrInputLive//Xidf_TI_MouseMove
			xidf_PerformTrInputLive( a, gpd, gpd2 );
		}
		inp.xistate.Gamepad = gpd2;
	}
	xidf_PerformCleanup();
	return 1;
}
/// Sets value using fraction.
/// \param fNewValFrac - new value in range 0.0 to 1.0.
///                      This must not be negative or greater than 1.0,
///                      unlike xidf_SetGamepadValueInt() where negative  values are expected.
/// \sa xidf_GetInputValueForAction()
void xidf_SetGamepadValueFl( int eAction, float fNewValFrac, XINPUT_GAMEPAD& gpd2 )
{
	int val = 0;
	fNewValFrac = std::abs( fNewValFrac );
	fNewValFrac = std::min<float>( 1.0f, fNewValFrac );
	if( eAction == Xidf_Act_LTr )
		val = static_cast<int>( fNewValFrac * Xidf_MaxTriggerPos );
	else if( eAction == Xidf_Act_RTr )
		val = static_cast<int>( fNewValFrac * Xidf_MaxTriggerPos );
	else if( eAction == Xidf_Act_LSXAdd ) //LSXPlus //&& gpd.sThumbLX > 0
		val = static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSXSub )
		val = -static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSYAdd )
		val = static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_LSYSub )
		val = -static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSXAdd )
		val = static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSXSub )
		val = -static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSYAdd )
		val = static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else if( eAction == Xidf_Act_RSYSub )
		val = -static_cast<int>( fNewValFrac * Xidf_MaxStickPos );
	else{
		val = ( fNewValFrac != 0.0f ? 1 : 0 );
	}
	xidf_SetGamepadValueInt( eAction, val, gpd2 );
}
/**
	Sets new value for specified input action.
	\param nNewValue - value to set. it is expected to be a negative
	                   integer value for inputs that assign negative axis values,
	                   like Act_RSYSub, and positive for others.

	\sa xidf_GetInputValueForAction()
*/
void xidf_SetGamepadValueInt( int eAction, int nNewValue, XINPUT_GAMEPAD& gpd2 )
{
	int mask2;
	if( (mask2 = xidf_ActionToBitIfAny( eAction ))){
		if( !nNewValue ){
			gpd2.wButtons &= ~mask2;
		}else
			gpd2.wButtons |= mask2;
	}else{
		if( eAction == Xidf_Act_LTr )
			//gpd2.bLeftTrigger = std::min<int>( nNewValue, Xidf_MaxTriggerPos );
			gpd2.bLeftTrigger = nNewValue;
		if( eAction == Xidf_Act_RTr )
			//gpd2.bRightTrigger = std::min<int>( nNewValue, Xidf_MaxTriggerPos );
			gpd2.bRightTrigger = nNewValue;
		if( eAction == Xidf_Act_LSXAdd ) //&& gpd.sThumbLX > 0 //LSXPlus
			gpd2.sThumbLX = nNewValue;
		if( eAction == Xidf_Act_LSXSub )
			gpd2.sThumbLX = nNewValue;
		if( eAction == Xidf_Act_LSYAdd )
			gpd2.sThumbLY = nNewValue;
		if( eAction == Xidf_Act_LSYSub )
			gpd2.sThumbLY = nNewValue;
		if( eAction == Xidf_Act_RSXAdd )
			gpd2.sThumbRX = nNewValue;
		if( eAction == Xidf_Act_RSXSub )
			gpd2.sThumbRX = nNewValue;
		if( eAction == Xidf_Act_RSYAdd )
			gpd2.sThumbRY = nNewValue;
		if( eAction == Xidf_Act_RSYSub )
			gpd2.sThumbRY = nNewValue;
			//gpd2.sThumbRY = xidf_ClampInt( nNewValue, -Xidf_MaxStickPos, Xidf_MaxStickPos );
	}
}
int xidf_StrToLimit( const char* inp, int eAct )
{
	int limit3 = -1;
	float fFrac = 0.0f;
	if( strchr( inp, '.' ) ){
		fFrac = (float)atof( inp );
	}else if( strchr( inp, '%' ) ){
		fFrac = ( 0.01f * atoi( inp ) );
	}else{
		limit3 = atoi( inp );
	}
	if( xidf_IsGamepadStickAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxStickPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxStickPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE );
		//XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
	}else if( xidf_IsGamepadTriggerAction( eAct ) ){
		limit3 = ( fFrac ? static_cast<int>( fFrac * Xidf_MaxTriggerPos ) : limit3 );
		limit3 = std::max<int>( 0, std::min<int>( Xidf_MaxTriggerPos, limit3 ) );
		limit3 = ( limit3 ? limit3 : XINPUT_GAMEPAD_TRIGGER_THRESHOLD );
	}
	return limit3;
}
Xidf_Modkey* xidf_FindModkeyById( int ident )
{
	assert( XidfGlobals6 );
	std::vector<Xidf_Modkey>::iterator a;
	a = std::find_if( XidfGlobals6->modkeys3.begin(), XidfGlobals6->modkeys3.end(),
			[&]( const Xidf_Modkey& a )->bool{
					return a.ident3 == ident;
	});
	if( a != XidfGlobals6->modkeys3.end() ){
		return &*a;
	}
	return 0;
}
bool
xidf_ParseTrInputs( const hxdw_IniData2& ini6, std::vector<Xidf_TrInput>& trOut, std::string* err2 )
{
	char bfr[512];
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	static const std::string srSecNameBgn2 = hxdw_TrimStr("s_input_tr:0", ":0", "R", -1 );
	std::vector<std::string> secnames = ini6.getSectionsByNamePrefix( srSecNameBgn2.c_str() );
	int nNr = 0;
	std::vector<std::string>::const_iterator a;
	for( a = secnames.begin(); a != secnames.end(); ++a, nNr++ ){
		std::string sname = *a;
		Xidf_TrInput tr2;
		std::string srMode  = ini6.getValue( sname.c_str(), "eTIMode" );
		std::string srHotk2 = ini6.getValue( sname.c_str(), "szHotkey2" );
		tr2.eOutputTy = xidf_StrToTrInputMode( srMode.c_str() );
		if( !tr2.eOutputTy ){
			sprintf_s( bfr, sizeof(bfr), "Unknown input-translation mode, [%s].eTIMode", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		if( !srHotk2.empty() ){ // allows no-hotkey tr-input.
			if(!xidf_ParseTriggerSequence( srHotk2.c_str(), tr2.trigger4, &err3, "" )){
				sprintf_s( bfr, sizeof(bfr), "Failed parsing trigger for tr-input, "
							"[%s].szHotkey2", sname.c_str() );
				err3 = bfr;
				return 0;
			}
		}
		std::string srInputs = ini6.getValue( sname.c_str(), "szInputs" );
		if( !xidf_ActionsToArray( srInputs.c_str(), ',', tr2.inputs2, &err3 ) ){
			sprintf_s( bfr, sizeof(bfr), "Failed parsing inputs, [%s].szInputs. [%s]", sname.c_str(), err3.c_str() );
			err3 = bfr;
			return 0;
		}
		if( tr2.inputs2.empty() ){
			sprintf_s( bfr, sizeof(bfr), "No input names. Empty: [%s].szInputs", sname.c_str() );
			err3 = bfr;
			return 0;
		}
		tr2.nMovementPerSec = atoi( ini6.getValue( sname.c_str(), "nMovementPerSec").c_str() );
		tr2.nMovementPerSec = ( tr2.nMovementPerSec ? tr2.nMovementPerSec : 512 );
		//tr2.eIntrplTy =

		tr2.ident5 = ++XidfGlobals6->nLastTr2Id;
		trOut.push_back( tr2 );
	}
	return 1;
}

int xidf_Reinterpolate( int val, int deadzone2, int nMaxPosition )
{
	int nMul = ( val < 0 ? -1 : 1 );
	val = std::abs( val );
	float frac = ( float(val-deadzone2) / (nMaxPosition-deadzone2) );
	val = int( frac * nMaxPosition * nMul );
	return val;
}
bool
xidf_IsRtneTriggerDown( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd, std::vector<int>* aPerTrgrDn2 )
{
	const Xidf_ModkeyDown* modd;
	std::vector<int> aSink, *aPerTrgrDn = ( aPerTrgrDn2 ? aPerTrgrDn2 : &aSink );
	if( trgr.modkeyIds.empty() && trgr.buttons2.empty() )
		return 0;
	bool bLive4 = 1;
	for( const auto& b : trgr.modkeyIds ){ // Xidf_Trigger
		modd = Xidf_ModkeyDown::findModkey( b, &XidfGlobals6->aModsDown[0], XidfGlobals6->aModsDown.size() );
		if( modd && modd->bDown2 ){
			aPerTrgrDn->push_back( modd->mod2->btnActivator );
		}else{
			bLive4 = 0;
			break;
		}
	}
	for( const auto& b : trgr.buttons2 ){
		if( !xidf_IsActionDown( b, gpd, {-1,-1,} ) ){
			bLive4 = 0;
			break;
		}else{
			aPerTrgrDn->push_back( b );
		}
	}
	return bLive4;
}
//
// FG-Squircular mapping.
// Mapping a square region to a circular disc.
// Disc to square mapping based on the Fernandez-Guasti squircle.
//
// Input:  (x,y) coordinates in the square.
// Output: (u,v) coordinates in the circle.
//
// Ref: http://squircular.blogspot.com/2015/09/fg-squircle-mapping.html
//      "Squircles FG-Squircular Mapping HTML.zip"
//
void xidf_FgsSquareToDisc( double x, double y, double* xo, double* yo )
{
	assert( xo && yo );
	if( x == 0.0 && y == 0.0 ){
		*xo = *yo = 0.0;
		return;
	}
	const double xm = x < 0 ? -1 : 1;
	const double ym = y < 0 ? -1 : 1;
	x = std::abs(x);
	y = std::abs(y);
	const double maxv = std::max<double>(x,y);
	x /= maxv;
	y /= maxv;

	double u = x, v = y;
    const double x2 = x * x;
    const double y2 = y * y;
    const double r2 = x2 + y2;
    const double rad = std::sqrt( r2 - x2 * y2);
    const double epsilon2 = std::numeric_limits<double>::epsilon();

    // avoid division by zero if (x,y) is closed to origin.
    if( r2 < epsilon2 ){
        //
    }else{
		// This code is amenable to the fast reciprocal sqrt floating point trick
		// https://en.wikipedia.org/wiki/Fast_inverse_square_root
		const double reciprocalSqrt =  1.0 / std::sqrt(r2);
		u = x * rad * reciprocalSqrt;
		v = y * rad * reciprocalSqrt;
	}
	u *= maxv * xm;
	v *= maxv * ym;
	*xo = u;
	*yo = v;
}
std::array<double,2>
xidf_Vec2dMultiplify2( std::array<double,2> vec2d2, double ffScalar )
{
	vec2d2[0] *= ffScalar;
	vec2d2[1] *= ffScalar;
	return vec2d2;
}
double xidf_Vec2dLengthSqA2( const std::array<double,2>& vec2d2 )
{
	return vec2d2[0] * vec2d2[0] + vec2d2[1] * vec2d2[1];
}
double xidf_Vec2dLengthA2( const std::array<double,2>& vec2d2 )
{
	return std::sqrt( xidf_Vec2dLengthSqA2(vec2d2) );
}
std::array<double,2>
xidf_Vec2dNormalize2( const std::array<double,2>& vec2d2 )
{
	if( vec2d2[0] < 0.00001 && vec2d2[1] < 0.00001 )
		return { 0.0, 0.0,};
	double ffLen = xidf_Vec2dLengthA2( vec2d2 );
	return xidf_Vec2dMultiplify2( vec2d2, 1.0/ffLen );
}

bool
xidf_PerformTrInputLive( Xidf_TrInputLive& tr3, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	if( xidf_IsRtneTriggerDown( tr3.trInput2->trigger4, gpd, 0 ) ){
		if( tr3.trInput2->eOutputTy == Xidf_TI_MouseMove ){ // "eMouseMotion"
			const XINPUT_GAMEPAD gp3 = xidf_EnforceAPIDeadZones( gpd, 1 );
			uint64_t nTmPos  = hxdw_GetTimeTicksUs();
			uint64_t nDeltaTMsecs = ( tr3.bLive3.second ? nTmPos - tr3.bLive3.second : 0 );
			float    fDeltaTSecs = float( double(nDeltaTMsecs) / 1000000.0 );
			if( fDeltaTSecs ){
				// get delta x and y using 4 inputs, specified previously in config.
				// all 4 map to up, right, down and left, in that order, respectivelly.
				const std::vector<int>& in2 = tr3.trInput2->inputs2;
				float upp    = ( in2.size() >= 1 ? xidf_GetInputValueForAction( in2[0], gp3 ).second : 0.f );
				float rightt = ( in2.size() >= 2 ? xidf_GetInputValueForAction( in2[1], gp3 ).second : 0.f );
				float downn  = ( in2.size() >= 3 ? xidf_GetInputValueForAction( in2[2], gp3 ).second : 0.f );
				float leftt  = ( in2.size() >= 4 ? xidf_GetInputValueForAction( in2[3], gp3 ).second : 0.f );
				double dx2 = (rightt - leftt) * fDeltaTSecs;
				double dy2 = (downn  - upp  ) * fDeltaTSecs;
				dx2 += tr3.aDeltaAccum[0];
				dy2 += tr3.aDeltaAccum[1];
				//
				//printf("%f\n", (float)dx2 );
				xidf_FgsSquareToDisc( dx2, dy2, &dx2, &dy2 ); //eIntrplTy
				int dx3 = static_cast<int>( dx2 * tr3.trInput2->nMovementPerSec );
				int dy3 = static_cast<int>( dy2 * tr3.trInput2->nMovementPerSec );
				// accumulators for sub second movement accuracy.
				tr3.aDeltaAccum[0] = ( !dx3 ? dx2 : 0.0 );
				tr3.aDeltaAccum[1] = ( !dy3 ? dy2 : 0.0 );

				//printf("dxdy: %f, %f\n", dx2, dy2 );
				//xCircle = xSquare * sqrt(1 - 0.5*ySquare^2)
				//yCircle = ySquare * sqrt(1 - 0.5*xSquare^2)
				//https://stackoverflow.com/questions/1621831/how-can-i-convert-coordinates-on-a-square-to-coordinates-on-a-circle
				//float dx4 = float(dx3) * sqrtf( 1.0 - 0.5 * pow(dy3,2) );
				//float dy4 = float(dy3) * sqrtf( 1.0 - 0.5 * pow(dx3,2) );

				hxdw_SendMouseDeltaInput( { dx3, dy3,} );
				//float len = sqrt( pow( dx3, 2 ) + pow( dy3, 2 ) );
				//printf("dxdy: %-2d, %-2d, len:%f, %d\n",
				//		dx3, dy3, (float)len, (int)nDeltaTMsecs );
			}
		}else{
			assert(!"Output type not implemented [UHdW5Q]");
		}
		tr3.bLive3 = { 1, hxdw_GetTimeTicksUs(),};
	}else{
		if( tr3.bLive3.first ){
			//printf("down2.\n");
			tr3.bLive3 = {0,0,};
		}
	}
	return 1;
}
int xidf_ApplyDeadZoneIfNeeded( int val, int deadzone2, int nMaxPosition )
{
	if( std::abs( val ) <= deadzone2 ){
		val = 0;
	}else if( nMaxPosition ){
		val = xidf_Reinterpolate( val, deadzone2, nMaxPosition );
	}
	return val;
}
int xidf_GetMouseFlags( int nMButton, const char* flags2 )
{
	bool bUp = !!strchr( flags2, 'u' );
	for( const auto& a : xidf_MButtonBits ){
		if( a.first == nMButton ){
			return ( !bUp ? a.second.first : a.second.second );
		}
	}
	return 0;
}
int xidf_FindModkeyByName( const char* modkname, const std::vector<Xidf_Modkey>& modkeys_ )
{
	for( const auto& a : modkeys_ ){
		if( a.rename2 == modkname ){
			return a.ident3;
		}
	}
	return 0;
}
void xidf_PerformCleanup()
{
	assert(XidfGlobals6);
	char bfrFl[32];
	uint64_t nTmNow = hxdw_GetTimeTicksUs();
	for( auto& rtne4 : XidfGlobals6->aRoutinesLive ){
		// Test keys for when need to terminate with key-up action.
		for( auto a = rtne4.aSendksLive.begin(); a != rtne4.aSendksLive.end(); ){
			auto endd = rtne4.routine2->aSendVk.end();
			auto b = std::find_if( rtne4.routine2->aSendVk.begin(), endd,
					[&]( const Xidf_SendKey& b ){
							return b.ident6 == a->first;
			});
			assert( b != endd );
			uint64_t nTmEnd = a->second + b->nIntrvl * 1000;
			if( nTmNow >= nTmEnd ){
				if( b->nMouseBtn ){
					int nMFlg = xidf_GetMouseFlags( b->nMouseBtn, "u" );
					hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
				}else{
					sprintf_s( bfrFl, sizeof(bfrFl), "u%s%s",
									( XidfGlobals6->bKeysUseWM ? "p" : "" ),
									( XidfGlobals6->bKeysUseSC ? "s" : "" ) );
					hxdw_SendKeyboardInput( {{ b->nVk, 0,},}, bfrFl ); //send key up. "u"
				}
				a = rtne4.aSendksLive.erase(a);  //Xidf_SendKey
			}else{
				++a;
			}
		}
	}
}
int xidf_StrToKeyAction( const char* inp )
{
	int len = (int)strlen(inp);
	if( !len )
		return 0;
	if( len == 1 ){
		char chr = *inp;
		if( chr >= 'a' && chr <= 'z' ){
			int vkc = ( 0x41 + ( chr - 'a' ) );  // 0x41: VK_A
			return vkc;
		}else if( chr >= 'A' && chr <= 'Z' ){
			int vkc = ( 0x41 + ( chr - 'A' ) );  // 0x41: VK_A
			return vkc;
		}else if( chr >= '0' && chr <= '9' ){
			int vkc = ( 0x30 + ( chr - '0' ) ); // 0x30: VK_0
			return vkc;
		}
	}else if( len == 2 && strchr("kK", inp[0] ) && std::isalpha( inp[1] ) ){
		char chr = inp[1];   // 0x41: VK_A
		int vkc = ( 0x41 + ( std::islower(chr) ? (chr - 'a') : (chr - 'A') ) );
		return vkc;
	}else if( len == 2 && strchr("Nn", inp[0] ) && strchr("0123456789", inp[1] ) ){
		// VK_NUMPAD0 - VK_NUMPAD9 // "n0" - "n9"
		int vkc = ( VK_NUMPAD0 + ( inp[1] - '0' ) );
		return vkc;
	}else{
		if( len >= 2 && strchr("Ff", inp[0] ) && strchr("0123456789", inp[1] ) ){
			// VK_F1 - VK_F24 // eg. "f12"
			int num = atoi( &inp[1] );
			if( num >= 1 && num <= 24 ){
				int vkc = ( VK_F1 + (num - 1) );
				return vkc;
			}
		}
		for( const auto& a : xidf_KeyNames ){
			for( auto b = a.second.begin(); b != a.second.end(); ++b ){
				if( !lstrcmpi( inp, b->c_str() ) ){
					return a.first;
				}
			}
		}
		if( len >= 2 && strchr("0123456789", inp[0] ) ){
			// if any number starting string, at least 2 characters long.
			return atoi( inp );
		}
	}
	return 0;
}
int xidf_StrToMouseButtonAction( const char* inp )
{
	int len = (int)strlen(inp);
	if( len == 2 && strchr("Mm", inp[0] ) && strchr("123456789", inp[1] ) ){
		return atoi( &inp[1] );
	}
	return 0;
}
bool xidf_StrToInputList( const char* szBtnNames, char glue2,
							std::vector<Xidf_Input>& outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	std::vector<std::string> btns;
	hxdw_StrExplode( szBtnNames, btns, {std::string(&glue2,1),}, -1, "\x20\t" );
	for( const auto& a : btns ){
		int actn;
		if( (actn = xidf_StrToGamepadAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_Gamepad, actn ) );
		}else if( (actn = xidf_StrToKeyAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_Key, actn ) );
		}else if( (actn = xidf_StrToMouseButtonAction( a.c_str() )) ){
			outp.push_back( Xidf_Input( Xidf_IT_MouseButton, actn ) );
		}else{
			char bfr[512];
			sprintf_s( bfr, sizeof(bfr), "Unrecognizaed input name '%s'. "
						"Eg. can be gamepad button.", a.c_str() );
			err3 = bfr;
			return 0;
		}
	}
	return 1;
}

void
xidf_RoutineLiveOnDown( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm__,
							const XINPUT_GAMEPAD& gpd__, XINPUT_GAMEPAD& gpd2__ )
{
	uint64_t uTmNow = hxdw_GetTimeTicksUs();
	char bfrFl[32];
	if( rtne2.routine2->eSimMode == Xidf_SM_Hold ){
		for( const auto& a : rtne2.routine2->aSendVk ){
			auto b = std::find_if( rtne2.aSendksLive.begin(), rtne2.aSendksLive.end(),
					[&]( const std::pair<int,uint64_t>& c ){
							return c.first == a.ident6;
			});
			if( a.nMouseBtn ){
				int nMFlg = xidf_GetMouseFlags( a.nMouseBtn, "" );
				hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
			}else{
				sprintf_s( bfrFl, sizeof(bfrFl), "%s%s",
								( XidfGlobals6->bKeysUseWM ? "p" : "" ),
								( XidfGlobals6->bKeysUseSC ? "s" : "" ) );
				hxdw_SendKeyboardInput( { { a.nVk, 0,},}, bfrFl );
			}
			if( b != rtne2.aSendksLive.end() ){
				b->second = uTmNow;
			}else{
				rtne2.aSendksLive.push_back( { a.ident6, uTmNow,} );
			}
		}
		for( const auto& a : rtne2.routine2->aHold2 ){ //Xidf_Input
			if( a.type2 == Xidf_IT_Key ){
				sprintf_s( bfrFl, sizeof(bfrFl), "%s%s",
								( XidfGlobals6->bKeysUseWM ? "p" : "" ),
								( XidfGlobals6->bKeysUseSC ? "s" : "" ) );
				hxdw_SendKeyboardInput( {{ a.input2, 0,},}, bfrFl );
			}else if( a.type2 == Xidf_IT_MouseButton ){
				int nMFlg = xidf_GetMouseFlags( a.input2, "" );
				hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
			}
		}
	}else if( rtne2.routine2->eSimMode == Xidf_SM_Autorepeat ){
		rtne2.aTurboBtnLive = { uTmNow, 0,};
	}
}
void
xidf_RoutineLiveOnUp( Xidf_RoutineLive& rtne2, const Xidf_Perform& pfrm__,
							const XINPUT_GAMEPAD& gpd__, XINPUT_GAMEPAD& gpd2__ )
{
	char bfrFl[32];
	for( const auto& a : rtne2.routine2->aHold2 ){ //Xidf_Input
		if( a.type2 == Xidf_IT_Key ){
			sprintf_s( bfrFl, sizeof(bfrFl), "u%s%s",
							( XidfGlobals6->bKeysUseWM ? "p" : "" ),
							( XidfGlobals6->bKeysUseSC ? "s" : "" ) );
			hxdw_SendKeyboardInput( {{ a.input2, 0,},}, bfrFl );
		}else if( a.type2 == Xidf_IT_MouseButton ){
			int nMFlg = xidf_GetMouseFlags( a.input2, "u" );
			hxdw_SendMouseButtonInput( {{nMFlg,0,},} );
		}
	}
}
/**
	Given definition, returns available pairs in the list of integers.

	\param aPairsDefined - definition of pairs. all elements map must be unique. permutations only.
*/
void xidf_GetAvailablePairs2( const std::vector<int>& inp,
		const std::vector<std::array<int,2> >& aPairsDefined,
		std::vector<std::array<int,2> >* pairs2 )
{
	assert( pairs2 );
	std::vector<int> actns2 = inp;
	for( auto iPair = aPairsDefined.begin(); iPair != aPairsDefined.end(); ++iPair ){
		auto bb2 = std::find( actns2.begin(), actns2.end(), iPair->at(0) );
		auto bb3 = std::find( actns2.begin(), actns2.end(), iPair->at(1) );
		if( bb2 != actns2.end() && bb3 != actns2.end() ){
			pairs2->push_back( std::array<int,2>{ *bb2, *bb3,} );
		}
	}
}
void
xidf_RoutineLivePerform( Xidf_RoutineLive& rtne2, const Xidf_Perform&,
							const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	assert( rtne2.routine2 );
	if( rtne2.routine2->eSimMode == Xidf_SM_Hold ){
		float fFirstVal = xidf_GetFirstValueForRtneTrigger( rtne2.routine2->trigger2, gpd ).second;
		std::vector<Xidf_Input>::const_iterator a; int i;
		// for each button held.
		for( i=0, a = rtne2.routine2->aHold2.begin(); a != rtne2.routine2->aHold2.end(); ++a, i++ ){
			if( a->type2 == Xidf_IT_Gamepad ){
				fFirstVal *= rtne2.routine2->getRescaleAtIfAny( i );
				xidf_SetGamepadValueFl( a->input2, fFirstVal, gpd2 );
			}
		}
	}else if( rtne2.routine2->eSimMode == Xidf_SM_Autorepeat ){
		xidf_RoutineLivePerformAutorepeat( rtne2, gpd, gpd2 );
	}else
		assert(!"Unexpected mode [wReUXC]");
	for( const auto& a : rtne2.routine2->aSuppress ){  // eg. {Xidf_Act_START,}
		if( !rtne2.routine2->isGamepadButtonLiveSimulated( a ) ){
			xidf_SetGamepadValueInt( a, 0, gpd2 );
		}
	}
	{
		float fNewScale = rtne2.routine2->fRescaleThese.fScale;  // Xidf_ScaleActions
		fNewScale = xidf_Clamp2<float>( fNewScale, 0.f, 1.f );
		if( fNewScale != 0.0f ){
			const char eType3 = rtne2.routine2->fRescaleThese.eType2;
			const uint32_t tck2 = GetTickCount();
			std::vector<std::array<int,2> > pairs2;
			xidf_GetAvailablePairs2( rtne2.routine2->fRescaleThese.aActions,
					xidf_ActnAnaglogueDrctnPairs, &pairs2 );
			//printf("n-pairs2: %d\n", int( pairs2.size() ) );
			auto lmbSetActnValRescaled = [&]( int eAct3, float fVal2 ){
				float fNewVal2 = (
					eType3 == '*' ? fNewScale * fVal2 : (
					eType3 == '+' ? fNewScale + fVal2 : (
					eType3 == '-' ? fNewScale - fVal2 : (
					fNewScale ) ) ) );
				fNewVal2 = xidf_Clamp2<float>( fNewVal2, 0.f, 1.f );
				//printf("t: %d, ac:%d, fNewVal2: %f\n", int(tck2), eAct3, fNewVal2 );
				xidf_SetGamepadValueFl( eAct3, fNewVal2, gpd2 );
			};
			auto lmbSetDiagonalActnsRescaled = [&]( std::array<int,2> eActnDiagonalPair ){
				float fVal0 = xidf_GetInputValueForAction( eActnDiagonalPair[0], gpd ).second;
				float fVal1 = xidf_GetInputValueForAction( eActnDiagonalPair[1], gpd ).second;
				std::array<double,2> aFfNewVal2 = { 0.0, 0.0,};

				xidf_FgsSquareToDisc( fVal0, fVal1, &aFfNewVal2[0], &aFfNewVal2[1] );
				//aFfNewVal2 = xidf_Vec2dNormalize2( { double(fVal0), double(fVal1),} );

				for( size_t ii2 = 0; ii2 < aFfNewVal2.size(); ii2++ ){
					lmbSetActnValRescaled( eActnDiagonalPair[ii2], aFfNewVal2[ii2] );
				}
			};
			const float epsilon3 = 0.001f;//0.21f;0.001f;//0.1f
			std::vector<int> rescaled2;
			if( !rtne2.routine2->fRescaleThese.bNoDiagonalAdjust2 ){
				for( auto ir2 = pairs2.begin(); ir2 != pairs2.end(); ++ir2 ){
					float fval2 = xidf_GetInputValueForAction( ir2->at(0), gpd ).second;
					float fval3 = xidf_GetInputValueForAction( ir2->at(1), gpd ).second;
					if( fval2 > epsilon3 && fval3 > epsilon3 ){
						//printf("t: %d, ac:[%d,%d] fv:[%f,%f]\n",
						//		int(tck2), ir2->at(0), ir2->at(1), fval2, fval3 );
						lmbSetDiagonalActnsRescaled( std::array<int,2>( *ir2 ) );
						rescaled2.push_back( ir2->at(0) );
						rescaled2.push_back( ir2->at(1) );
					}
				}
			}
			for( auto actn2 : rtne2.routine2->fRescaleThese.aActions ){   // eg. {Xidf_Act_LTr,}
				if( !xidf_AnyOfA2( rescaled2, actn2 ) ){
					float fval4 = xidf_GetInputValueForAction( actn2, gpd ).second;
					if( fval4 > epsilon3 ){
						lmbSetActnValRescaled( actn2, fval4 );
					}
				}
			}
		}
	}
}
void
xidf_RoutineLivePerformAutorepeat( Xidf_RoutineLive& rtne5, const XINPUT_GAMEPAD& gpd, XINPUT_GAMEPAD& gpd2 )
{
	const uint64_t uTmNow2 = hxdw_GetTimeTicksUs();
	assert( uTmNow2 >= rtne5.aTurboBtnLive.first );
	const Xidf_AutoRepeat& turbo3 = rtne5.routine2->turbo2;
	std::vector<std::pair<int,float> > lsInputs;
	lsInputs = xidf_GetValuesForRtneTrigger( rtne5.routine2->trigger2, gpd );
	const uint64_t uDeltaT = uTmNow2 - rtne5.aTurboBtnLive.first;
	const uint64_t uARDrtn = turbo3.uTmDown + turbo3.uTmUp;
	const uint64_t uARPos  = uDeltaT % uARDrtn; //nNumMissed
	const bool bDown       = ( uARPos <= turbo3.uTmDown );

	std::vector<Xidf_Input>::const_iterator a; int i = 0;
	// for each button to simulate.
	for( a = rtne5.routine2->aHold2.begin(); a != rtne5.routine2->aHold2.end(); ++a, i++ ){
		if( a->type2 == Xidf_IT_Gamepad ){
			float fVal = ( !bDown ? 0.f : ( i < lsInputs.size() ? lsInputs[i].second : 1.f ) );
			xidf_SetGamepadValueFl( a->input2, fVal, gpd2 );  //LSXPlus
		}
	}
}
std::pair<int,float>
xidf_GetFirstValueForRtneTrigger( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd )
{
	std::vector<std::pair<int,float> > lsInputs;
	lsInputs = xidf_GetValuesForRtneTrigger( trgr, gpd );
	if( !lsInputs.empty() )
		return lsInputs[0];
	return { 0, 0.f,};
}
std::vector<std::pair<int,float> >
xidf_GetValuesForRtneTrigger( const Xidf_Trigger& trgr, const XINPUT_GAMEPAD& gpd )
{
	std::vector<std::pair<int,float> > outp;
	const Xidf_ModkeyDown* modd;
	std::pair<int,float> val;
	for( const auto& a : trgr.order2 ){
		if( a.second ){   // if modkey, an index to id in trgr.modkeyIds.
			int id3 = trgr.modkeyIds[a.first];
			modd = Xidf_ModkeyDown::findModkey( id3, &XidfGlobals6->aModsDown[0], XidfGlobals6->aModsDown.size() );
			assert( modd && modd->mod2 );
			assert( modd->mod2->btnActivator );
			val = xidf_GetInputValueForAction( modd->mod2->btnActivator, gpd );
			outp.push_back( val );
		}else{
			val = xidf_GetInputValueForAction( trgr.buttons2[a.first], gpd );
			outp.push_back( val );
		}
	}
	return outp;
}


std::string xidf_GetLocalTimeStr()
{
	char buf[128];
	SYSTEMTIME stt;
	GetLocalTime( &stt ); // Local time
	sprintf_s( buf, sizeof(buf), "%04u%02u%02u%02u%02u%02u",
			stt.wYear, stt.wMonth, stt.wDay,
			stt.wHour, stt.wMinute, stt.wSecond ); // 24h format
	return buf;
}

void xidf_LogMessage( const char* szLabel, const char* szMsg )
{
	if( !XidfGlobals6->srLogFile.empty() ){ //XidfGlobals6->bNoLogFile
		FILE* fp2 = fopen( XidfGlobals6->srLogFile.c_str(), "ab" );
		if(fp2){
			std::string srMesg;
			if( szLabel && *szLabel )
				srMesg += std::string(szLabel) + "\x20";
			srMesg += hxdw_TrimStr( szMsg, "\r\n", "R", -1 );
			char bfr2[2048];
			sprintf_s( bfr2, sizeof(bfr2), "%d: %s\r\n", _getpid(), srMesg.c_str() );
			fwrite( bfr2, 1, strlen(bfr2), fp2 );
			fclose(fp2);
		}
	}
}

bool XidfXiReader::xireaderInit()
{
	if( !XidfGlobals6->sXiRd.bXiEnabled )
		return 1;
	if( XidfGlobals6->sXiRd.eScrapMode == Xidf_P2_Thread ){
		XidfGlobals6->sXiRd.hScrapThr = CreateThread( 0,0, []( void* )->DWORD{
				//
				for( ;; ){
					//xidf_XiReaderInternalPerform();
					XidfXiReader::xireaderPerform();
					uint32_t uMillis = (uint32_t) XidfGlobals6->sXiRd.fSleepIntervalMs;
					Sleep( uMillis );
					if( !XidfGlobals6->sXiRd.bRunThr )
						break;
				}
				return 0;
		}, 0, 0, 0 );
	}else if( XidfGlobals6->sXiRd.eScrapMode == Xidf_P2_TranslateMsgApi ){
		//DetourTransactionBegin();
		//DetourUpdateThread( GetCurrentThread() );
		//DetourAttach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
		//DetourTransactionCommit();
	}
	return 1;
}
bool XidfXiReader::xireaderPerform()
{
	if( !XidfGlobals6->sXiRd.bXiEnabled )
		return 1;
	XINPUT_STATE xse;
	memset( &xse, 0, sizeof(XINPUT_STATE) );
	XInputGetState( 0, &xse );
	return 1;
}
bool XidfXiReader::xireaderDeinit()
{
	if( !XidfGlobals6->sXiRd.bXiEnabled )
		return 1;
	if( XidfGlobals6->sXiRd.hScrapThr ){
		XidfGlobals6->sXiRd.bRunThr = 0;
		for( ;; ){ // spin and wait for thread to terminate itself.
			DWORD rslt = WaitForSingleObject( XidfGlobals6->sXiRd.hScrapThr, 0 );
			if( rslt == WAIT_OBJECT_0 ){
				// if the thread handle is signaled - the thread has terminated.
				// else the thread handle is not signaled - the thread is still alive.
				break;
			}
			uint32_t msWait = (uint32_t)( XidfGlobals6->sXiRd.fSleepIntervalMs / 2.0 );
			Sleep( msWait );
		}
	}
	return 1;
}
void XidfCfg::resetCfg()
{
	*this = XidfCfg();
}
std::string xidf_GetButtonActionNames( char delim2 )
{
	std::string outp;
	for( const auto& a : xidf_ActNames ){
		outp += a.second;
		outp += delim2;
	}
	if( !outp.empty() && outp.back() == delim2 )
		outp.resize( outp.size()-1 );
	return outp;
}
/// Returns delimeter separated key/button names as string.
/// \param flags3 - flags, eg. \ref Xidf_KT_KeyNamesLong.
std::string xidf_GetKeyboardKeyNames( char delim2, int flags3 )
{
	std::string outp;
	char bfr[64];
	if( flags3 & Xidf_KT_KeyNamesLong ){
		for( const auto& a : xidf_KeyNames ){
			if( !a.second.empty() ){
				outp += a.second[0];
				outp += delim2;
			}
		}
	}
	if( flags3 & Xidf_KT_KeyNamesAZ ){
		memcpy( bfr, "\0\0", 2 );
		for( char k = 'A'; k < 'Z'+1; k++ ){
			sprintf_s( bfr, sizeof(bfr), "k%c", k );  //eg. "kA" - key a
			outp += bfr;
			outp += delim2;
		}
	}
	if( flags3 & Xidf_KT_KeyNames0To9 ){
		memcpy( bfr, "\0\0", 2 );
		for( char k = '0'; k < '9'+1; k++ ){
			bfr[0] = k;
			outp += bfr;
			outp += delim2;
		}
	}
	if( flags3 & Xidf_KT_KeyNames09Numpad ){
		for( int i = 0; i < 9+1; i++ ){ //n0-n9
			sprintf_s( bfr, sizeof(bfr), "n%d", i );
			outp += bfr;
			outp += delim2;
		}
	}
	if( flags3 & Xidf_KT_KeyNamesF1F2Etc ){
		for( int i = 1; i < 12+1; i++ ){ //f1-f12
			sprintf_s( bfr, sizeof(bfr), "f%d", i ); //eg. f12
			outp += bfr;
			outp += delim2;
		}
	}
	if( flags3 & Xidf_KT_MouseButtonNames ){
		for( int i = 1; i < 9+1; i++ ){
			//sprintf( bfr, "m%d", i ); //eg. m1
			sprintf_s( bfr, sizeof(bfr), "m%d", i ); //eg. m1
			outp += bfr;
			outp += delim2;
		}
	}
	if( !outp.empty() && outp.back() == delim2 )
		outp.resize( outp.size()-1 );
	return outp;
}
std::string xidf_GetModkeyNames( char delim2 )
{
	std::string outp;
	assert( XidfGlobals6 );
	for( const auto& a : XidfGlobals6->modkeys3 ){
		if( !a.rename2.empty() ){
			outp += a.rename2;
			outp += delim2;
		}
	}
	return outp;
}
float Xidf_Routine::getRescaleAtIfAny( int nIndex )const
{
//	std::vector<int>::const_iterator a;
//	const std::vector<int>& indexes2 = fRRescale.second;
//	if( fRRescale.first == 0.0f || fRRescale.first == 1.0f )
//		return 1.0f;
//	a = std::find( indexes2.begin(), indexes2.end(), nIndex );
//	if( a != indexes2.end() )
//		return fRRescale.first;
	return 1.0f;
}
bool Xidf_Routine::isGamepadButtonLiveSimulated( int eAction )const
{
	std::vector<Xidf_Input>::const_iterator a;
	a = std::find_if( aHold2.begin(), aHold2.end(), [&]( const Xidf_Input& a )->bool{
			return ( a.type2 == Xidf_IT_Gamepad && a.input2 == eAction );
	});
	return ( a != aHold2.end() );
}
//int xidf_ClampInt( int inp, int loww, int highh )
//{
//	return std::max<int>( std::min<int>( inp, highh ), loww );
//}
XidfGlobals5::~XidfGlobals5()
{
	if( this->ini7 ){
		delete this->ini7;
		this->ini7 = 0;
	}
}
void XidfGlobals5::readIniFileIfNeeded3()
{
	if( !this->ini7 ){
		assert( !this->srCfgFname.empty() );
		this->ini7 = new hxdw_IniData2;
		*this->ini7 = hxdw_ParseINIFile( this->srCfgFname.c_str() );
	}
}
bool xidf_IsKeyStateDown( int nVirtKey2 )
{
	static const std::vector<std::vector<int> > aVkSame2 = {
		{ VK_SHIFT,   VK_LSHIFT,   VK_RSHIFT,},
		{ VK_CONTROL, VK_LCONTROL, VK_RCONTROL,},
		{ VK_MENU,    VK_LMENU,    VK_RMENU,}, //the Alt key|modkey
	};
	auto irSame = std::find_if( aVkSame2.begin(), aVkSame2.end(),
		[&]( const std::vector<int>& in2 )->bool{
			auto a = std::find( in2.begin(), in2.end(), nVirtKey2 );
			return a != in2.end();
	});
	for( auto irRL2 = XidfGlobals6->aRoutinesLive.begin(); irRL2 != XidfGlobals6->aRoutinesLive.end(); ++irRL2 ){
		assert( irRL2->routine2 );
		if( irRL2->bLive && irRL2->routine2->eSimMode == Xidf_SM_Hold ){
			const auto& ls2 = irRL2->routine2->aHold2;
			for( auto ir3 = ls2.begin(); ir3 != ls2.end(); ++ir3 ){
				if( ir3->type2 == Xidf_IT_Key ){
					if( ir3->input2 == nVirtKey2 ){
						return 1L;
					}
					if( irSame != aVkSame2.end() ){
						auto ir4 = std::find( irSame->begin(), irSame->end(), ir3->input2 );
						if( ir4 != irSame->end() ){
							return 1L;
						}
					}
				}
			}
		}
	}
	return 0L;
}


