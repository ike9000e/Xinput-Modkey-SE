#include "xidf_init.h"
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1
#include <windows.h>
#include <xinput.h>
#include "detours.h"
#include "MinHook.h"    //MH_Initialize()
#include <process.h>   //_getpid()
#include <assert.h>
#include <algorithm>
#include <list>
#include <mmsystem.h>   //PlaySound()
#include "xidf_functions.h"
//#include "xidf_resource.h"
//#include "hxdw/hxdw_utils.h"
#include "xims_utils.h"

/*
	typedef struct _XINPUT_STATE {
	  DWORD          dwPacketNumber;
	  XINPUT_GAMEPAD Gamepad;
	} XINPUT_STATE, *PXINPUT_STATE;
	typedef struct _XINPUT_GAMEPAD {
	  WORD  wButtons;
	  BYTE  bLeftTrigger;
	  BYTE  bRightTrigger;
	  SHORT sThumbLX;
	  SHORT sThumbLY;
	  SHORT sThumbRX;
	  SHORT sThumbRY;
	} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;
*/
//using XInputGetState_t = DWORD __stdcall( DWORD dwUserIndex,XINPUT_STATE *pState );
//DWORD (WINAPI*  ori_XInputGetState)( DWORD dwUserIndex, XINPUT_STATE *pState ) = XInputGetState;
//DWORD WINAPI    xidf_XInputGetState( DWORD dwUserIndex, XINPUT_STATE *pState );

extern XidfGlobals5* XidfGlobals6;

bool xidf_InitGlobalData( void* hInstance )
{
	assert( XidfGlobals6 );
	HINSTANCE hInstance2 = (HINSTANCE) hInstance;

	char bfr2[MAX_PATH] = ""; std::string str4, err2;
	if( !XidfGlobals6->bNoLogFile ){
		const char* sz2; std::string srTmpDir;
		std::list<std::string> aTmps2 = {"%TEMP%","%TMP%",};
		*bfr2 = 0;
		GetSystemDirectory( bfr2, sizeof(bfr2) );
		if( bfr2[0] && bfr2[1] == ':' ){
			bfr2[1] = '\0';
			aTmps2.push_front( hxdw_StrPrintf("%s:\\temp", {{bfr2,},} ) ); // yields fe. "C:\\Temp".
		}
		for( const auto& a : aTmps2 ){
			if( a[0] == '%' ){
				str4 = hxdw_TrimStr( a, "%", "LR", -1 );
				if( (sz2 = getenv( str4.c_str() )) ){
					if( hxdw_IsDir( sz2 ) ){
						srTmpDir = sz2;
						break;
					}
				}
			}else if( hxdw_IsDir( a.c_str() ) ){
				srTmpDir = a.c_str();
				break;
			}
		}
		if( !srTmpDir.empty() ){
			sprintf_s( bfr2, sizeof(bfr2), "%s\\xinput_modkey.log", srTmpDir.c_str() );
			XidfGlobals6->srLogFile = bfr2;
			printf("XIDF: Log file: [%s]\n", XidfGlobals6->srLogFile.c_str() );
			if( (128*1024) < hxdw_GetFileSize( XidfGlobals6->srLogFile.c_str() ) ){
				DeleteFile( XidfGlobals6->srLogFile.c_str() );
			}
		}
	}
	GetModuleFileName( hInstance2, bfr2, sizeof(bfr2) );
	XidfGlobals6->srDllPath = bfr2;

	if( !XidfGlobals6->srLogFile.empty() ){ //XidfGlobals6->bNoLogFile
		sprintf_s( bfr2, sizeof(bfr2), "%s Starting from [%s]",
				xidf_GetLocalTimeStr().c_str(), XidfGlobals6->srDllPath.c_str() );
		xidf_LogMessage( "", bfr2 );
		//
		GetModuleFileName( 0, bfr2, sizeof(bfr2)-1 );
		std::string srExec = bfr2;
		sprintf_s( bfr2, sizeof(bfr2), "Executable name [%s]", srExec.c_str() );
		xidf_LogMessage( "", bfr2 );
	}
	std::pair<std::string,std::string> dp2;
	dp2 = hxdw_SplitPath( XidfGlobals6->srDllPath.c_str() );
	XidfGlobals6->srCfgFname = dp2.first + "\\" + hxdw_SplitExt( dp2.second.c_str() ).first + ".ini";

	sprintf_s( bfr2, sizeof(bfr2), "XIDF: Config path: [%s]", XidfGlobals6->srCfgFname.c_str() );
	printf("%s\n", bfr2 );
	xidf_LogMessage("", bfr2 );

	if( !hxdw_FileExists( XidfGlobals6->srCfgFname.c_str() ) ){
		printf("XIDF: ERROR: configuration file not found.\n");
		return 0;
	}
	hxdw_IniData2 ini_a = hxdw_ParseINIFile( XidfGlobals6->srCfgFname.c_str() );
	//MessageBox(0, ini_a.getAsString().c_str(), "Cfg", 0);
	if( !xidf_ReinitConfiguration2( ini_a ) ){
		return 0;
	}
	return 1;
}

/// Replacer for Xinput own XInputGetState() Winapi function.
DWORD WINAPI xidf_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pState )
{
	pState->Gamepad.wButtons;
	//printf("wButtons: 0x%X\n", uint32_t(pState->Gamepad.wButtons) );
	assert( XidfGlobals6 );
	assert( XidfGlobals6->sWaFncs.XInputGetState );
	using fn_t = decltype(xidf_XInputGetState)*;
	fn_t lpOrig2 = reinterpret_cast<fn_t>( XidfGlobals6->sWaFncs.XInputGetState );
	DWORD rv2 = lpOrig2( dwUserIndex, pState );

//	if( XidfGlobals6->bEnforceAPIDeadzones ){
//		xidf_EnforceAPIDeadZones( gpd, XidfGlobals6->bADZReinterpolate );
//	}
	Xidf_Perform prf( *pState, dwUserIndex );
	xidf_PerformModkeys( prf );

//	static bool bOnce = 0;
//	if( !bOnce ){
//		bOnce = 1;
//		if( !XidfGlobals6->bNoStartupSnd ){
//			CreateThread( 0,0, []( void* )->DWORD{
//					PlaySound( MAKEINTRESOURCE( IDR_WAVE_DLL_STARTUP ),
//									XidfGlobals6->hInst2, SND_RESOURCE );
//					return 0;
//			}, 0, 0, 0 );
//		}
//	}
	return rv2;
}
//GetAsyncKeyState//GetKeyState//GetKeyboardState
SHORT WINAPI xidf_GetAsyncKeyState( int nVirtKey2 )
{
	//assert( nVirtKey2 != VK_HOME );
	//if( nVirtKey2 == VK_HOME ){
	//	if( (GetTickCount() % 3000) > 2000 ){
	//		return 0x8000;
	//	}
	//}
	static_assert( sizeof(SHORT) == 2, "");
	assert( XidfGlobals6 );
	using fn_t = decltype(xidf_GetAsyncKeyState)*;
	fn_t lpOrig2 = reinterpret_cast<fn_t>( XidfGlobals6->sWaFncs.GetAsyncKeyState );
	SHORT rv2 = lpOrig2( nVirtKey2 );
	if( !rv2 && xidf_IsKeyStateDown( nVirtKey2 ) ){
		rv2 |= 0x8000;
	}
	return rv2;
}
SHORT WINAPI xidf_GetKeyState( int nVirtKey2 )
{
	assert( XidfGlobals6 );
	//assert( nVirtKey2 != VK_HOME );
	using fn_t = decltype(xidf_GetKeyState)*;
	fn_t lpOrig2 = reinterpret_cast<fn_t>( XidfGlobals6->sWaFncs.GetKeyState );
	SHORT rv2 = lpOrig2( nVirtKey2 );
	if( !rv2 && xidf_IsKeyStateDown( nVirtKey2 ) ){
		rv2 |= 0x8000;
	}
	return rv2;
}
/*BOOL WINAPI xidf_GetKeyboardState( PBYTE lpKeyState2 )
{
	//assert(!"xidf_GetKeyboardState");
	assert( XidfGlobals6 );
	using fn_t = decltype(xidf_GetKeyboardState)*;
	fn_t lpOrig2 = reinterpret_cast<fn_t>( XidfGlobals6->sWaFncs.GetKeyboardState );
	BOOL rv3 = lpOrig2( lpKeyState2 );
	if( xidf_IsKeyStateDown( VK_HOME ) ){
		//assert(!"xidf_GetKeyboardState h");
		static_assert( VK_HOME < 256, "");
		lpKeyState2[VK_HOME] = 0xFF;
	}
	return rv3;
}//*/
/*
//GetMessage,GetMessageA,GetMessageW
//BOOL WINAPI xidf_GetMessageW( LPMSG lpMsg, HWND hWnd, UINT wMsgFilterMin, UINT wMsgFilterMax )
BOOL WINAPI xidf_PeekMessageAW( MSG* lpMsg, HWND hWnd, UINT wMsgFilterMin,
		UINT wMsgFilterMax, UINT wRemoveMsg )
{
	assert( XidfGlobals6 );
	assert( XidfGlobals6->sWaFncs.PeekMessageAW );
	using fn_t = decltype(xidf_PeekMessageAW)*;
	fn_t lpOrig2 = reinterpret_cast<fn_t>( XidfGlobals6->sWaFncs.PeekMessageAW );
	BOOL rv2 = lpOrig2( lpMsg, hWnd, wMsgFilterMin, wMsgFilterMax, wRemoveMsg );
	if( lpMsg->message == WM_SYSKEYDOWN || lpMsg->message == WM_KEYDOWN ){
		if( lpMsg->wParam == VK_HOME ){
			assert(0);
		}
	}
	return rv2;
}//*/

//long === MH_STATUS
long
xidf_CreateEnabledMHDetour( void* pAddress, void** ppOrigCall, void* pDetour, bool bCreateEnabled )
{
	MH_STATUS rs2;
	rs2 = MH_CreateHook( pAddress, pDetour, ppOrigCall );
	if( rs2 ){
		return rs2;
	}
	if( bCreateEnabled ){
		rs2 = MH_EnableHook( pAddress );
		if( rs2 ){
			return rs2;
		}
	}
	return MH_OK; // MH_OK=0.
}

/**
	Per-process initialization.
	F.e. called durning DllMain.
	Deinit is done via xidf_DeinitForProcess().
*/
bool xidf_InitForProcess( void* hInstance )
{
	assert( !XidfGlobals6 );
	HINSTANCE hInstance2 = reinterpret_cast<HINSTANCE>( hInstance );
	if( !hInstance2 ){
		//hInstance2 = GetModuleHandle( 0 );
		GetModuleHandleExA( GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
					(LPCSTR)(&XidfGlobals6), &hInstance2 );
		assert( hInstance2 );
	}
	XidfGlobals6 = new XidfGlobals5;
	printf("XIDF: Starting DLL\n");
	XidfGlobals6->hInst2 = hInstance2;

	//PlaySound( TEXT("SystemStart"), 0, SND_ALIAS );
	//PlaySound( (LPCTSTR)SND_ALIAS_SYSTEMSTART, NULL, SND_ALIAS_ID );
	// The following example plays a sound-file resource:
	// PlaySound( MAKEINTRESOURCE(IDR_WAVE1),
	//     GetModuleHandle(0),
	//     SND_RESOURCE);

	if( MH_Initialize() ){
		xidf_LogMessage("", "XIDF: MH_Initialize() failed [SZ0MWq]");
		assert(!"XIDF: MH_Initialize() failed [G8cJey]");
	}

	//printf("XIDF: dll path: [%s]\n", XidfGlobals6->srDllPath.c_str() );
	xidf_InitGlobalData( hInstance2 );
	XidfGlobals6->readIniFileIfNeeded3();
	//xidf_ReinitConfiguration3("r");
	//XidfGlobals6->ini7.bKeysUseSC;
	{
	//	DetourTransactionBegin();
	//	DetourUpdateThread( GetCurrentThread() );
	//	std::shared_ptr<void> sbrm2( 0, [&](void*){
	//		DetourTransactionCommit();
	//	});
		if( XidfGlobals6->srXiDllFName.empty() ){
			assert(!"Empty configuration variable [s_main].szXinputDllName is unexpected [kTMb2b]");
		}
		//MessageBox(0,"ERR", XidfGlobals6->srXiDllFName.c_str(), 0);
		if( XidfGlobals6->srXiDllFName == "eDAuto" ){
			XidfGlobals6->srXiDllFName = "";
			// Enumerate DLLs in the PE executable.
			for( HMODULE hDll3 = 0; (hDll3 = DetourEnumerateModules(hDll3)); ){
				std::string str2;
				char szName[MAX_PATH] = {0,};
				GetModuleFileNameA(hDll3, szName, sizeof(szName) - 1);
				str2 = hxdw_SplitPath( szName ).second;
				// Below: matches successfully with: "XINPUT9_1_0.dll", "Xinput1_3.dll", etc.
				//        Value '6' stands for the char that follows the "xinput" text.
				if( !hxdw_StrCmpOpt( "xinput", str2.c_str(), 6, "i" ) ){
					if( strchr( "19", str2[6] ) ){
						XidfGlobals6->srXiDllFName = str2;
						//printf("DLL: [%s]\n", str2.c_str() );
						break;
					}
				}
			}
		}
		char bfr2[256];
		sprintf_s( bfr2, sizeof(bfr2), "Using Xinput DLL [%s]", XidfGlobals6->srXiDllFName.c_str() );
		printf("XIDF: %s\n", bfr2 );
		xidf_LogMessage("", bfr2 );
		if( XidfGlobals6->srXiDllFName.empty() ){
			assert(!"XIDF: Couldn't find valid Xinput DLL module name [CBMgZ5]");
		}
		XidfGlobals6->hXiDll = LoadLibrary( XidfGlobals6->srXiDllFName.c_str() );
		assert( XidfGlobals6->hXiDll );
		//ori_XInputGetState = (XInputGetState_t*) GetProcAddress( XidfGlobals6->hXiDll, "XInputGetState" );
		//assert( ori_XInputGetState );
		XidfGlobals6->sWaFncs.XInputGetState = (void*) GetProcAddress( XidfGlobals6->hXiDll, "XInputGetState" );
		assert( XidfGlobals6->sWaFncs.XInputGetState );
		//DetourAttach( &(void*)ori_XInputGetState, xidf_XInputGetState );

		auto rs2 = xidf_CreateEnabledMHDetour(
				(void*)XidfGlobals6->sWaFncs.XInputGetState,
				(void**)&XidfGlobals6->sWaFncs.XInputGetState,
				(void*)xidf_XInputGetState, 1L );
		assert( rs2 == MH_OK );//*/
		{
			HMODULE hUser32 = LoadLibrary("user32.dll");
			assert( hUser32 );
			//
			assert( XidfGlobals6->ini7 );
			const bool bEnableGAKSApi2 = !!atoi( XidfGlobals6->ini7->getValue("s_main","bEnableGAKSApi2","0").c_str() );
			const bool bEnableGKSApi3 = !!atoi( XidfGlobals6->ini7->getValue("s_main","bEnableGKSApi3","0").c_str() );
			if( bEnableGAKSApi2 ){
				XidfGlobals6->sWaFncs.GetAsyncKeyState = (void*) GetProcAddress( hUser32, "GetAsyncKeyState");
				assert( XidfGlobals6->sWaFncs.GetAsyncKeyState );
				//DetourAttach( &(void*)XidfGlobals6->sWaFncs.GetAsyncKeyState, xidf_GetAsyncKeyState );
				auto rs2 = xidf_CreateEnabledMHDetour(
						(void*)XidfGlobals6->sWaFncs.GetAsyncKeyState,
						(void**)&XidfGlobals6->sWaFncs.GetAsyncKeyState,
						(void*)xidf_GetAsyncKeyState, 1L );
				assert( rs2 == MH_OK );
			}
			if( bEnableGKSApi3 ){
				XidfGlobals6->sWaFncs.GetKeyState = (void*) GetProcAddress( hUser32, "GetKeyState");
				assert( XidfGlobals6->sWaFncs.GetKeyState );
				auto rs2 = xidf_CreateEnabledMHDetour(
						(void*)XidfGlobals6->sWaFncs.GetKeyState,
						(void**)&XidfGlobals6->sWaFncs.GetKeyState,
						(void*)xidf_GetKeyState, 1L );
				assert( rs2 == MH_OK );
			}
			{
			/*	XidfGlobals6->sWaFncs.GetKeyboardState = (void*) GetProcAddress( hUser32, "GetKeyboardState");
				assert( XidfGlobals6->sWaFncs.GetKeyboardState );
				auto rs2 = xidf_CreateEnabledMHDetour(
						(void*)XidfGlobals6->sWaFncs.GetKeyboardState,
						(void**)&XidfGlobals6->sWaFncs.GetKeyboardState,
						(void*)xidf_GetKeyboardState, 1L );
				assert( rs2 == MH_OK );//*/
			}
		/*	{
				XidfGlobals6->sWaFncs.PeekMessageAW = (void*) GetProcAddress( hUser32, "PeekMessageA");
				assert( XidfGlobals6->sWaFncs.PeekMessageAW );
				auto rs2 = xidf_CreateEnabledMHDetour(
						(void*)XidfGlobals6->sWaFncs.PeekMessageAW,
						(void**)&XidfGlobals6->sWaFncs.PeekMessageAW,
						(void*)xidf_PeekMessageAW, 1L );
				assert( rs2 == MH_OK );
			}//*/
		}
	}
	if( XidfGlobals6->sXiRd.bXiEnabled ){
		XidfXiReader::xireaderInit();
	}
	return 1L;
}
void xidf_DeinitForProcess()
{
	assert( XidfGlobals6 );
	xidf_LogMessage("", "DLL_PROCESS_DETACH");
/*	DetourTransactionBegin();
	DetourUpdateThread( GetCurrentThread() );
	//DetourDetach( &(PVOID &)ori_XInputGetState, xidf_XInputGetState );
	DetourTransactionCommit();///*/
	//
	MH_Uninitialize();
	//
	if( XidfGlobals6->sXiRd.bXiEnabled ){
		XidfXiReader::xireaderDeinit();
	}
	if( XidfGlobals6->hXiDll ){
		FreeLibrary( XidfGlobals6->hXiDll );
		XidfGlobals6->hXiDll = 0;
	}
	delete XidfGlobals6;
	XidfGlobals6 = 0;
}
const char* xidf_GetCurrentConfigFileName()
{
	assert( XidfGlobals6 );
	return XidfGlobals6->srCfgFname.c_str();
}
bool xidf_ReinitConfiguration2( const hxdw_IniData2& ini2, std::string* err3 )
{
	std::string str3;
	std::string dmy0, &err2 = ( err3 ? *err3 : dmy0 );
	assert(XidfGlobals6);
	XidfGlobals6->resetCfg();

	XidfGlobals6->bEnforceAPIDeadzones = !!atoi( ini2.getValue( "s_main", "bEnforceAPIDeadzones" ).c_str() );
	XidfGlobals6->bADZReinterpolate = !!atoi( ini2.getValue( "s_main", "bADZReinterpolate" ).c_str() );
//	XidfGlobals6->nGamepadIndex = !!atoi( ini2.getValue( "s_main", "nGamepadIndex" ).c_str() );
	XidfGlobals6->bKeysUseWM = !!atoi( ini2.getValue( "s_main", "bKeysUseWM" ).c_str() );
	XidfGlobals6->bKeysUseSC = !!atoi( ini2.getValue( "s_main", "bKeysUseSC" ).c_str() );
	XidfGlobals6->bNoStartupSnd = !!atoi( ini2.getValue( "s_main", "bNoStartupSnd" ).c_str() );
	XidfGlobals6->bNoLogFile = !!atoi( ini2.getValue( "s_main", "bNoLogFile" ).c_str() );
	XidfGlobals6->srXiDllFName = ini2.getValue("s_main", "szXinputDllName" ).c_str();
	XidfGlobals6->srGlobalSuppress = ini2.getValue("s_main", "szGlobalSuppress" ).c_str();
	XidfGlobals6->sXiRd.bXiEnabled = !!atoi( ini2.getValue( "s_internal_xinput", "bXiEnabled" ).c_str() );
	XidfGlobals6->sXiRd.fSleepIntervalMs = atof( ini2.getValue( "s_internal_xinput", "fSleepIntervalMs" ).c_str() );
	//
	if( !(str3 = XidfGlobals6->srGlobalSuppress.c_str() ).empty() ){
		if( !xidf_ActionsToArray( str3.c_str(), ',', XidfGlobals6->aGlobSuppr, &err2 ) ){
			printf("XIDF: ERROR: %s\n", err2.c_str() );
			xidf_LogMessage("ERROR", err2.c_str() );
			return 0;
		}
	}
	float fff = static_cast<float>( XidfGlobals6->sXiRd.fSleepIntervalMs );
	XidfGlobals6->sXiRd.fSleepIntervalMs = ( fff ? fff : XidfGlobals6->sXiRd.fSleepIntervalMs );
	//
	if( !xidf_ParseModkeys2( ini2, XidfGlobals6->modkeys3, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfGlobals6->modkeys3 ){
		XidfGlobals6->aModsDown.push_back( Xidf_ModkeyDown( &a ) );
	}
	if( !xidf_ParseTrInputs( ini2, XidfGlobals6->trInputs, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		return 0;
	}
	for( const auto& a : XidfGlobals6->trInputs ){
		XidfGlobals6->aTrInputLive.push_back( Xidf_TrInputLive( &a ) );
	}

	if( !xidf_ParseRoutines( ini2, XidfGlobals6->routines2, &err2 ) ){
		printf("XIDF: ERROR: %s\n", err2.c_str() );
		xidf_LogMessage("ERROR", err2.c_str() );
		//MessageBox(0, err2.c_str(), "XIDF", 0);
		return 0;
	}
	for( const auto& a : XidfGlobals6->routines2 ){
		XidfGlobals6->aRoutinesLive.push_back( Xidf_RoutineLive( &a ) );
	}
	XidfGlobals6->bInited = 1;
	return 1;
}
/// Reads and/or writes INI configuration file based on the 'flags2' parameter.
/// Regardless of the flags parameter, any values that has been added to the
/// global INI object wont be removed, will be saved to the file.
XidfQuad2<bool,std::string>
xidf_ReinitConfiguration3( const char* flags2 )
{
	const bool bRealoadCfg = std::strchr( flags2, 'r');
	const bool bWriteCfg = std::strchr( flags2, 'w');
	assert( bRealoadCfg || bWriteCfg );
	assert( XidfGlobals6 );
	if( bRealoadCfg ){
		XidfGlobals6->readIniFileIfNeeded3();
		assert( XidfGlobals6->ini7 );
		std::string err2;
		bool rs2 = xidf_ReinitConfiguration2( *XidfGlobals6->ini7, &err2 );
		if(!rs2){
			return { 0L, err2,};
		}
	}
	if( bWriteCfg ){
		assert( XidfGlobals6->ini7 );
		std::string data2 = XidfGlobals6->ini7->getAsString();
		std::string srFnm = xidf_GetCurrentConfigFileName();
		//srFnm += "002.ini";
		assert( !srFnm.empty() );
		if( !hxdw_PutFileContents( srFnm.c_str(), data2.c_str(), (int)data2.size() ) ){
			std::string err3;
			err3 = "Failed writing configuration file. ";
			err3 += "[" + srFnm + "]";
			return { 0L, err3,};
		}
	}
	return { 1L, "",};   //success.
}


